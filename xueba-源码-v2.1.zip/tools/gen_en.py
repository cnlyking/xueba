# -*- coding: utf-8 -*-
"""成为学霸 英语题库生成器（三年级起）"""
import json, os, random

random.seed(20261118)

WORDS = [
    ("apple", "苹果"), ("banana", "香蕉"), ("orange", "橙子"), ("pear", "梨"), ("grape", "葡萄"),
    ("water", "水"), ("milk", "牛奶"), ("bread", "面包"), ("cake", "蛋糕"), ("rice", "米饭"),
    ("egg", "鸡蛋"), ("fish", "鱼"), ("meat", "肉"), ("noodle", "面条"), ("tea", "茶"),
    ("juice", "果汁"), ("candy", "糖果"), ("ice cream", "冰淇淋"),
    ("cat", "猫"), ("dog", "狗"), ("bird", "鸟"), ("tiger", "老虎"), ("lion", "狮子"),
    ("monkey", "猴子"), ("panda", "熊猫"), ("elephant", "大象"), ("rabbit", "兔子"),
    ("duck", "鸭子"), ("pig", "猪"), ("horse", "马"), ("sheep", "绵羊"), ("mouse", "老鼠"),
    ("bear", "熊"), ("fox", "狐狸"), ("wolf", "狼"), ("deer", "鹿"),
    ("red", "红色"), ("blue", "蓝色"), ("green", "绿色"), ("yellow", "黄色"),
    ("black", "黑色"), ("white", "白色"), ("purple", "紫色"), ("pink", "粉色"), ("brown", "棕色"),
    ("father", "爸爸"), ("mother", "妈妈"), ("brother", "兄弟"), ("sister", "姐妹"),
    ("grandpa", "爷爷"), ("grandma", "奶奶"), ("uncle", "叔叔"), ("aunt", "阿姨"),
    ("friend", "朋友"), ("teacher", "老师"), ("student", "学生"), ("doctor", "医生"),
    ("nurse", "护士"), ("driver", "司机"), ("farmer", "农民"), ("worker", "工人"),
    ("book", "书"), ("pen", "钢笔"), ("pencil", "铅笔"), ("ruler", "尺子"), ("eraser", "橡皮"),
    ("bag", "书包"), ("desk", "书桌"), ("chair", "椅子"), ("school", "学校"),
    ("classroom", "教室"), ("library", "图书馆"), ("playground", "操场"), ("blackboard", "黑板"),
    ("head", "头"), ("hand", "手"), ("eye", "眼睛"), ("ear", "耳朵"), ("nose", "鼻子"),
    ("mouth", "嘴"), ("foot", "脚"), ("leg", "腿"), ("arm", "胳膊"), ("hair", "头发"),
    ("sun", "太阳"), ("moon", "月亮"), ("star", "星星"), ("sky", "天空"), ("rain", "雨"),
    ("snow", "雪"), ("wind", "风"), ("cloud", "云"), ("tree", "树"), ("flower", "花"),
    ("grass", "草"), ("sea", "大海"), ("river", "河流"), ("mountain", "山"), ("lake", "湖"),
    ("spring", "春天"), ("summer", "夏天"), ("autumn", "秋天"), ("winter", "冬天"),
    ("Monday", "星期一"), ("Tuesday", "星期二"), ("Wednesday", "星期三"),
    ("Thursday", "星期四"), ("Friday", "星期五"), ("Saturday", "星期六"), ("Sunday", "星期日"),
    ("morning", "早晨"), ("afternoon", "下午"), ("evening", "傍晚"), ("night", "夜晚"),
    ("today", "今天"), ("tomorrow", "明天"), ("yesterday", "昨天"),
    ("big", "大的"), ("small", "小的"), ("long", "长的"), ("short", "短的"), ("tall", "高的"),
    ("old", "年老的"), ("young", "年轻的"), ("new", "新的"), ("happy", "高兴的"),
    ("sad", "伤心的"), ("hot", "热的"), ("cold", "冷的"), ("fast", "快的"), ("slow", "慢的"),
    ("good", "好的"), ("bad", "坏的"), ("clean", "干净的"), ("dirty", "脏的"),
    ("run", "跑"), ("jump", "跳"), ("swim", "游泳"), ("sing", "唱歌"), ("dance", "跳舞"),
    ("read", "读"), ("write", "写"), ("draw", "画"), ("play", "玩"), ("eat", "吃"),
    ("drink", "喝"), ("sleep", "睡觉"), ("walk", "走"), ("fly", "飞"), ("sit", "坐"),
    ("stand", "站"), ("listen", "听"), ("speak", "说"), ("watch", "看"), ("help", "帮助"),
]

PLURAL = [("book", "books"), ("cat", "cats"), ("dog", "dogs"), ("pen", "pens"),
          ("apple", "apples"), ("bus", "buses"), ("box", "boxes"), ("watch", "watches"),
          ("baby", "babies"), ("city", "cities"), ("knife", "knives"), ("leaf", "leaves"),
          ("foot", "feet"), ("tooth", "teeth"), ("mouse", "mice"), ("child", "children"),
          ("man", "men"), ("woman", "women"), ("sheep", "sheep"), ("fish", "fish")]

BE = [("I", "am"), ("you", "are"), ("he", "is"), ("she", "is"), ("it", "is"),
      ("we", "are"), ("they", "are"), ("Tom", "is"), ("Lily and I", "are")]

PREP = [("The book is ___ the desk.", "on", ["in", "at", "under"]),
        ("The cat is ___ the box.", "in", ["on", "at", "to"]),
        ("I go to school ___ Monday.", "on", ["in", "at", "to"]),
        ("She gets up ___ seven o'clock.", "at", ["on", "in", "to"]),
        ("We have lunch ___ noon.", "at", ["on", "in", "for"]),
        ("The ball is ___ the chair.", "under", ["on", "in", "at"])]

TENSE = [("He ___ apples every day.", "likes", ["like", "liking", "liked"]),
         ("She ___ to school by bus.", "goes", ["go", "going", "went"]),
         ("I ___ my homework every evening.", "do", ["does", "doing", "did"]),
         ("They ___ football on Sundays.", "play", ["plays", "playing", "played"]),
         ("My mother ___ dinner at six.", "cooks", ["cook", "cooking", "cooked"])]

ARTICLE = [("This is ___ apple.", "an", ["a", "the", "不填"]),
           ("That is ___ book.", "a", ["an", "the", "不填"]),
           ("___ sun is very bright.", "The", ["A", "An", "不填"]),
           ("I have ___ orange.", "an", ["a", "the", "不填"])]

WH = [("___ is your name?", "What", ["Who", "Where", "How"]),
      ("___ old are you?", "How", ["What", "Who", "Where"]),
      ("___ is your teacher?", "Who", ["What", "Where", "How"]),
      ("___ do you live?", "Where", ["What", "Who", "How"]),
      ("___ is this in English?", "What", ["Who", "Where", "How"]),
      ("___ are you? I'm fine.", "How", ["What", "Who", "Where"])]

DIALOG = [("How are you?", "Fine, thank you.", ["I'm ten.", "It's a book.", "Yes, I do."]),
          ("What's your name?", "My name is Tom.", ["I'm fine.", "It's red.", "Thank you."]),
          ("How old are you?", "I'm ten years old.", ["I'm fine.", "Yes, I am.", "It's Monday."]),
          ("What's this?", "It's a pencil.", ["I'm nine.", "Yes, it is.", "Good morning."]),
          ("Nice to meet you.", "Nice to meet you, too.", ["I'm sorry.", "Thank you.", "Good night."]),
          ("Thank you.", "You're welcome.", ["Sorry.", "Hello.", "Goodbye."]),
          ("Good morning!", "Good morning!", ["Good night.", "Goodbye.", "Thank you."]),
          ("What day is it today?", "It's Monday.", ["It's sunny.", "I'm ten.", "It's a cat."])]

LETTER = [("A", ["B", "C", "D"]), ("b", ["a", "c", "d"]), ("F", ["E", "G", "H"]),
          ("m", ["l", "n", "o"]), ("Z", ["Y", "X", "W"])]


def make(q, right, pool, d=1, tip=""):
    opts = [right]
    for p in pool:
        if p != right and p not in opts:
            opts.append(p)
        if len(opts) == 4:
            break
    if len(opts) < 4:
        return None
    random.shuffle(opts)
    return {"type": "single", "q": q, "a": opts, "k": opts.index(right), "difficulty": d, "tip": tip}


def gen(grade):
    out = []
    d0 = 1 if grade == 3 else (2 if grade == 4 else 3)
    # 单词中英互译
    for w, cn in WORDS:
        pool = [x[1] for x in WORDS if x[0] != w]
        r = make(f"“{w}”是什么意思？", cn, pool, d0)
        if r: out.append(r)
        pool2 = [x[0] for x in WORDS if x[1] != cn]
        r = make(f"“{cn}”用英语怎么说？", w, pool2, d0)
        if r: out.append(r)
    # 复数
    if grade >= 4:
        for one, many in PLURAL:
            pool = [x[1] for x in PLURAL if x[0] != one]
            r = make(f"“{one}”的复数形式是？", many, pool, d0, "不规则复数要单独记")
            if r: out.append(r)
    # be 动词
    for subj, be in BE:
        pool = ["am", "is", "are"]
        r = make(f"I ___ ..." if False else f"{subj} ___ fine.", be, [p for p in pool if p != be], 1,
                 "am 配 I，is 配第三人称单数，are 配 you/we/they")
        if r: out.append(r)
    # 介词
    if grade >= 4:
        for sent, ans, others in PREP:
            r = make(sent, ans, others, d0)
            if r: out.append(r)
    # 时态
    if grade >= 5:
        for sent, ans, others in TENSE:
            r = make(sent, ans, others, 3, "第三人称单数动词要加 s")
            if r: out.append(r)
        for sent, ans, others in ARTICLE:
            r = make(sent, ans, others, 3, "元音音素开头用 an")
            if r: out.append(r)
    # 疑问词
    for sent, ans, others in WH:
        r = make(sent, ans, others, d0)
        if r: out.append(r)
    # 对话
    for q0, a0, others in DIALOG:
        r = make(f"别人说“{q0}”，合适回答是？", a0, others, d0)
        if r: out.append(r)
    # 字母
    for up, others in LETTER:
        r = make(f"和“{up}”相邻的下一个字母是？", others[0], others, 1)
        if r: out.append(r)
    return out


NAME = {1: "一年级", 2: "二年级", 3: "三年级", 4: "四年级", 5: "五年级", 6: "六年级"}
if __name__ == "__main__":
    outdir = r"D:\android-build\banks_out"
    os.makedirs(outdir, exist_ok=True)
    for g in range(3, 7):
        items = gen(g)
        seen, uniq = set(), []
        for it in items:
            if it["q"] in seen:
                continue
            seen.add(it["q"])
            uniq.append(it)
        json.dump({"name": f"{NAME[g]} · 英语", "version": 1, "subject": "英语", "grade": g, "items": uniq},
                  open(os.path.join(outdir, f"en{g}.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(NAME[g], "英语", len(uniq))
