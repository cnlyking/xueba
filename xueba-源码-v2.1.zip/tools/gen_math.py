# -*- coding: utf-8 -*-
"""成为学霸 数学生成器：1-6 年级，每题四选一，答案可计算验证"""
import random, json, os, sys, math

random.seed(20261116)

LA = ["小明", "小红", "小刚", "小丽", "小华", "小明", "小红", "小强", "小美", "小杰"]
LB = ["苹果", "梨", "糖", "铅笔", "本子", "气球", "贴纸", "玻璃球", "桃子", "橘子"]
LC = ["袋", "盒", "筐", "箱", "堆"]


def fmt(v):
    if isinstance(v, float):
        if abs(v - round(v)) < 1e-9:
            return str(int(round(v)))
        return ("%.2f" % v).rstrip("0").rstrip(".")
    return str(v)


def make(qt, right, distractor_pool, difficulty=1, tip=""):
    """right 是正确答案(字符串)，从干扰池取3个不同的"""
    opts = [fmt(right)]
    for d in distractor_pool:
        d = fmt(d)
        if d != str(right) and d not in opts:
            opts.append(d)
        if len(opts) == 4:
            break
    if len(opts) < 4:
        return None
    random.shuffle(opts)
    return {"type": "single", "q": qt, "a": opts, "k": opts.index(fmt(right)),
            "difficulty": difficulty, "tip": tip}


def num_distractors(n, cnt=6):
    """围绕正确答案生成合理的错误值"""
    out = []
    for d in (-2, -1, 1, 2, 3, -3, 10, -10):
        v = n + d
        if v >= 0:
            out.append(v)
    return out[:cnt]


# ---------------- 一年级 ----------------
def g1():
    out = []
    # 20以内加法
    for a in range(0, 21):
        for b in range(0, 21 - a):
            if a + b < 2:
                continue
            r = make(f"{a} + {b} = ?", a + b, num_distractors(a + b), 1)
            if r: out.append(r)
    # 20以内减法
    for a in range(2, 21):
        for b in range(1, a):
            r = make(f"{a} - {b} = ?", a - b, num_distractors(a - b), 1)
            if r: out.append(r)
    # 比大小
    for _ in range(400):
        a, b = random.randint(0, 20), random.randint(0, 20)
        if a == b:
            continue
        right = ">" if a > b else "<"
        r = make(f"比较大小：{a} ○ {b}，○ 里应填什么？", right, ["<", ">", "=", "≤"], 1)
        if r: out.append(r)
    # 数的组成
    for t in range(2, 10):
        for u in range(0, 10):
            n = t * 10 + u
            r = make(f"{n} 是由几个十和几个一组成的？", f"{t} 个十和 {u} 个一",
                     [f"{u} 个十和 {t} 个一", f"{t} 个十和 {u} 个十", f"{t} 个一和 {u} 个十"], 2)
            if r: out.append(r)
    # 找规律
    for st in range(0, 10):
        for step in (1, 2, 3, 5):
            s = f"{st}、{st + step}、{st + 2 * step}、{st + 3 * step}，接下来是？"
            nxt = st + 4 * step
            r = make(s, nxt, [nxt + step, nxt - step, nxt + 2], 2, f"每次加 {step}")
            if r: out.append(r)
    # 应用题
    for _ in range(6000):
        a = random.randint(3, 15)
        b = random.randint(1, a)
        nm, it = random.choice(LA), random.choice(LB)
        tip = "求剩下的用减法"
        r = make(f"{nm}有{a}个{it}，吃了{b}个，还剩几个？", a - b, num_distractors(a - b), 2, tip)
        if r: out.append(r)
    for _ in range(5000):
        a = random.randint(2, 10)
        b = random.randint(1, 20 - a)
        nm, it = random.choice(LA), random.choice(LB)
        r = make(f"{nm}有{a}个{it}，妈妈又给了{b}个，现在有几个？", a + b, num_distractors(a + b), 2, "求一共用加法")
        if r: out.append(r)
    for _ in range(3000):
        a = random.randint(3, 15)
        b = random.randint(1, a)
        nm, it = random.choice(LA), random.choice(LB)
        r = make(f"树上有{a}只{it}，飞走{b}只，还剩几只？", a - b, num_distractors(a - b), 2, "飞走用减法")
        if r: out.append(r)
    for _ in range(3000):
        a = random.randint(3, 15)
        b = random.randint(1, a)
        r = make(f"{nm}有{a}元钱，买本子花了{b}元，还剩几元？", a - b, num_distractors(a - b), 2, "花掉用减法")
        if r: out.append(r)
    for _ in range(3000):
        a = random.randint(2, 10)
        b = random.randint(2, 10)
        it = random.choice(LB)
        r = make(f"第一组有{a}个{it}，第二组有{b}个{it}，两组一共有多少个？", a + b, num_distractors(a + b), 2, "求一共用加法")
        if r: out.append(r)
    # 数的分成
    for t in range(2, 11):
        for a in range(0, t + 1):
            b = t - a
            r = make(f"{t} 可以分成 {a} 和几？", b, num_distractors(b), 1, "数的分成")
            if r: out.append(r)
    # 几十加几
    for t in range(1, 10):
        for u in range(1, 10):
            r = make(f"{t}0 + {u} = ?", t * 10 + u, [t * 10, t + u, t * 10 + u + 10], 1)
            if r: out.append(r)
    # 数数
    for _ in range(600):
        a = random.randint(0, 15)
        b = a + random.randint(2, 8)
        r = make(f"从 {a} 数到 {b}，一共数了几个数？", b - a + 1, [b - a, b - a + 2, b + a], 2)
        if r: out.append(r)
    # 连加连减
    for _ in range(800):
        a = random.randint(1, 10); b = random.randint(1, 10); c = random.randint(1, 10)
        if a + b + c > 20:
            continue
        r = make(f"{a} + {b} + {c} = ?", a + b + c, num_distractors(a + b + c), 2)
        if r: out.append(r)
    # 凑十
    for a in range(1, 10):
        r = make(f"{a} 和几凑成 10？", 10 - a, num_distractors(10 - a), 1, "凑十法")
        if r: out.append(r)
    return out


# ---------------- 二年级 ----------------
def g2():
    out = []
    for a in range(1, 100):
        for b in range(1, 101 - a):
            r = make(f"{a} + {b} = ?", a + b, num_distractors(a + b), 2)
            if r: out.append(r)
    for a in range(21, 101):
        for b in range(1, a, 4):
            r = make(f"{a} - {b} = ?", a - b, num_distractors(a - b), 2)
            if r: out.append(r)
    # 乘法口诀
    for a in range(1, 10):
        for b in range(1, 10):
            r = make(f"{a} × {b} = ?", a * b, num_distractors(a * b), 2, f"口诀：{a}几得{'几' if a * b < 10 else ''}")
            if r: out.append(r)
    # 除法
    for a in range(2, 10):
        for b in range(2, 10):
            r = make(f"{a * b} ÷ {a} = ?", b, [b + 1, b - 1, a * b], 2)
            if r: out.append(r)
    # 单位换算
    for m in range(1, 30):
        r = make(f"{m} 米 = ? 厘米", m * 100, [m * 10, m * 1000, m], 3, "1 米 = 100 厘米")
        if r: out.append(r)
    for m in range(1, 20):
        r = make(f"{m} 元 = ? 角", m * 10, [m, m * 100, m * 5], 2, "1 元 = 10 角")
        if r: out.append(r)
    # 应用题
    for _ in range(4000):
        g = random.randint(2, 9)
        n = random.randint(2, 9)
        it = random.choice(LB)
        cont = random.choice(LC)
        r = make(f"每{cont}装{g}个{it}，{n}{cont}一共有多少个？", g * n,
                 num_distractors(g * n), 3, "求几个几，用乘法")
        if r: out.append(r)
    for _ in range(2500):
        tot = random.randint(20, 99)
        d = random.randint(2, 9)
        if tot % d:
            continue
        nm, it = random.choice(LA), random.choice(LB)
        r = make(f"{tot}个{it}平均分给{d}个人，每人分几个？", tot // d, num_distractors(tot // d), 3, "平均分用除法")
        if r: out.append(r)
    # 长度单位换算
    for m in range(1, 20):
        r = make(f"{m} 分米 = ? 厘米", m * 10, [m, m * 100, m + 10], 2, "1 分米 = 10 厘米")
        if r: out.append(r)
        r = make(f"{m * 10} 厘米 = ? 分米", m, [m * 10, m + 1, m * 100], 2, "10 厘米 = 1 分米")
        if r: out.append(r)
    # 时间推算
    for _ in range(1500):
        h1 = random.randint(1, 11)
        m1 = random.choice([0, 10, 20, 30, 40, 50])
        dur = random.choice([30, 40, 50, 60, 90, 120])
        total = h1 * 60 + m1 + dur
        if total >= 12 * 60:
            total -= 12 * 60
        r = make(f"从 {h1} 时 {m1} 分开始，过了 {dur} 分钟，是几时几分？",
                 f"{total // 60} 时 {total % 60} 分",
                 [f"{total // 60} 时 {(total % 60 + 10) % 60} 分", f"{h1} 时 {dur % 60} 分", f"{h1 + 1} 时 {m1} 分"], 3,
                 "分钟相加满 60 进 1 小时")
        if r: out.append(r)
    # 倍数
    for _ in range(1800):
        a = random.randint(2, 20)
        k = random.randint(2, 9)
        nm = random.choice(LA)
        r = make(f"{nm}有{a}元，小红的钱是他的{k}倍，小红有多少元？", a * k, [a + k, a * k + a, a * k - a], 3, "求几倍用乘法")
        if r: out.append(r)
    # 图形边数
    for name, n in (("三角形", 3), ("正方形", 4), ("长方形", 4), ("五边形", 5), ("六边形", 6)):
        r = make(f"{name}有几条边？", n, [n + 1, n - 1, n + 2], 1)
        if r: out.append(r)
    return out


# ---------------- 三年级 ----------------
def g3():
    out = []
    # 两位数乘一位数
    for a in range(11, 100):
        b = random.randint(2, 9)
        r = make(f"{a} × {b} = ?", a * b, num_distractors(a * b), 3)
        if r: out.append(r)
    # 三位数加减
    for _ in range(2500):
        a = random.randint(100, 999)
        b = random.randint(10, 999)
        r = make(f"{a} + {b} = ?", a + b, num_distractors(a + b), 3)
        if r: out.append(r)
    for _ in range(2000):
        a = random.randint(200, 999)
        b = random.randint(10, a)
        r = make(f"{a} - {b} = ?", a - b, num_distractors(a - b), 3)
        if r: out.append(r)
    # 有余数除法
    for _ in range(1500):
        d = random.randint(2, 9)
        qq = random.randint(10, 99)
        rr = random.randint(1, d - 1)
        n = d * qq + rr
        r = make(f"{n} ÷ {d} = ? 余 ?", f"{qq} 余 {rr}",
                 [f"{qq} 余 {rr + 1}", f"{qq + 1} 余 {rr}", f"{qq} 余 0"], 3, f"余数必须小于除数 {d}")
        if r: out.append(r)
    # 周长
    for _ in range(1200):
        a, b = random.randint(3, 30), random.randint(3, 30)
        r = make(f"长 {a} 厘米、宽 {b} 厘米的长方形，周长是多少厘米？", 2 * (a + b),
                 [a + b, 2 * (a + b) + 2, a * b], 3, "周长 =（长 + 宽）× 2")
        if r: out.append(r)
    for s in range(2, 40):
        r = make(f"边长 {s} 厘米的正方形，周长是多少厘米？", 4 * s, [s * s, 2 * s, 4 * s + 4], 2, "正方形周长 = 边长 × 4")
        if r: out.append(r)
    # 时间
    for _ in range(1000):
        h = random.randint(1, 12)
        m = random.choice([10, 15, 20, 25, 30, 40, 45, 50])
        r = make(f"{h} 时 {m} 分，一共是多少分钟？", h * 60 + m, [h * 100 + m, h * 60, h + m], 3, "1 小时 = 60 分钟")
        if r: out.append(r)
    # 分数初步
    for d in range(2, 13):
        for n in range(1, d):
            r = make(f"把一个蛋糕平均分成 {d} 份，其中的 {n} 份是这个蛋糕的几分之几？", f"{n}/{d}",
                     [f"{d}/{n}", f"{n}/{d + 1}", f"1/{d}"], 3, "分母是总份数，分子是取的份数")
            if r: out.append(r)
    # 应用题
    for _ in range(1800):
        p = random.randint(2, 15)
        n = random.randint(3, 20)
        nm = random.choice(LA)
        r = make(f"{nm}每天看 {p} 页书，{n} 天一共看多少页？", p * n, num_distractors(p * n), 3)
        if r: out.append(r)
    # 两位数除以一位数
    for _ in range(1800):
        d = random.randint(2, 9)
        qq = random.randint(11, 99)
        r = make(f"{d * qq} ÷ {d} = ?", qq, [qq + 1, qq - 1, qq * 2], 3)
        if r: out.append(r)
    # 长方形正方形面积
    for _ in range(1500):
        a, b = random.randint(3, 30), random.randint(3, 30)
        r = make(f"长 {a} 厘米、宽 {b} 厘米的长方形，面积是多少平方厘米？", a * b,
                 [2 * (a + b), a * b + a, a + b], 3, "面积 = 长 × 宽")
        if r: out.append(r)
    for s in range(2, 40):
        r = make(f"边长 {s} 厘米的正方形，面积是多少平方厘米？", s * s, [4 * s, s * s + s, 2 * s], 2,
                 "正方形面积 = 边长 × 边长")
        if r: out.append(r)
    # 同分母分数比较
    for d in range(3, 15):
        for n1 in range(1, d):
            n2 = random.randint(1, d - 1)
            if n1 == n2:
                continue
            r = make(f"比较大小：{n1}/{d} ○ {n2}/{d}", ">" if n1 > n2 else "<", ["<", ">", "=", "无法比较"], 3,
                     "分母相同，分子大的分数大")
            if r: out.append(r)
    # 估算
    for _ in range(800):
        a = random.randint(11, 89)
        b = random.randint(2, 9)
        ra = round(a / 10) * 10
        right = ra * b
        r = make(f"{a} × {b} 大约是多少？（先把 {a} 看成整十数）", right,
                 [right + 10, right - 10, right + b], 3, "先把两位数看成整十数再算")
        if r: out.append(r)
    return out


# ---------------- 四年级 ----------------
def g4():
    out = []
    for a in range(11, 99, 2):
        for b in range(11, 99, 2):
            r = make(f"{a} × {b} = ?", a * b, num_distractors(a * b, 8), 3)
            if r: out.append(r)
    for _ in range(5200):
        a, b, c = random.randint(2, 30), random.randint(2, 20), random.randint(2, 20)
        if random.random() < 0.5:
            r = make(f"{a} × {b} + {c} = ?", a * b + c, num_distractors(a * b + c, 8), 3, "先乘后加")
        else:
            r = make(f"{a} × ({b} + {c}) = ?", a * (b + c), num_distractors(a * (b + c), 8), 3, "先算括号里的")
        if r: out.append(r)
    # 面积
    for _ in range(1200):
        a, b = random.randint(5, 40), random.randint(5, 40)
        r = make(f"长 {a} 米、宽 {b} 米的长方形，面积是多少平方米？", a * b, [2 * (a + b), a * b + a, a + b], 3, "面积 = 长 × 宽")
        if r: out.append(r)
    for s in range(3, 40):
        r = make(f"边长 {s} 米的正方形，面积是多少平方米？", s * s, [4 * s, s * s + s, 2 * s], 2, "正方形面积 = 边长 × 边长")
        if r: out.append(r)
    # 三角形面积
    for _ in range(800):
        a = random.choice([4, 6, 8, 10, 12, 16, 20])
        h = random.choice([3, 5, 6, 7, 9, 11])
        if a * h % 2:
            continue
        r = make(f"底 {a} 厘米、高 {h} 厘米的三角形，面积是多少平方厘米？", a * h // 2, [a * h, a + h, a * h // 2 + 2], 3, "三角形面积 = 底 × 高 ÷ 2")
        if r: out.append(r)
    # 速度
    for _ in range(1000):
        v = random.randint(20, 90)
        t = random.randint(2, 9)
        r = make(f"一辆车每小时行 {v} 千米，{t} 小时行多少千米？", v * t, [v + t, v / t if v % t == 0 else v * t + v, v * t + v], 3, "路程 = 速度 × 时间")
        if r: out.append(r)
    # 数位与计数
    for _ in range(2000):
        n = random.randint(100, 9999)
        place = random.choice(["十", "百", "千"])
        v = {"十": (n // 10) % 10, "百": (n // 100) % 10, "千": (n // 1000) % 10}[place]
        r = make(f"{n} 的{place}位上是几？", v, [v + 1, v - 1, (v + 2) % 10], 3, "从右往左数：个、十、百、千")
        if r: out.append(r)
    # 三位数除以两位数
    for _ in range(2000):
        d = random.randint(11, 40)
        qq = random.randint(3, 20)
        n = d * qq
        if n > 999:
            continue
        r = make(f"{n} ÷ {d} = ?", qq, [qq + 1, qq - 1, qq * 2], 3)
        if r: out.append(r)
    # 单位换算
    for m in range(1, 40):
        r = make(f"{m} 吨 = ? 千克", m * 1000, [m * 100, m * 10, m], 2, "1 吨 = 1000 千克")
        if r: out.append(r)
        r = make(f"{m * 1000} 千克 = ? 吨", m, [m * 10, m * 100, m * 1000], 2, "1000 千克 = 1 吨")
        if r: out.append(r)
    # 小数加减
    for _ in range(2000):
        a = round(random.uniform(0.1, 20), 1)
        b = round(random.uniform(0.1, 20), 1)
        r = make(f"{a} + {b} = ?", round(a + b, 1), [round(a + b + 0.1, 1), round(a + b - 0.1, 1), round(a + b + 1, 1)], 3)
        if r: out.append(r)
    # 角度
    for deg in range(10, 180, 5):
        r = make(f"一个角是 {deg}°，比直角小还是大？", "小" if deg < 90 else "大", ["大", "小", "一样", "无法判断"], 3, "直角是 90°")
        if r and r["q"] not in {x["q"] for x in out}: out.append(r)
    return out


# ---------------- 五年级 ----------------
def g5():
    out = []
    # 小数加减
    for _ in range(4200):
        a = round(random.uniform(1, 50), 1)
        b = round(random.uniform(1, 50), 1)
        r = make(f"{a} + {b} = ?", round(a + b, 1), [round(a + b + 0.1, 1), round(a + b - 0.1, 1), round(a + b + 1, 1)], 3)
        if r: out.append(r)
        r = make(f"{a} - {b} = ?", round(a - b, 1), [round(a - b + 0.1, 1), round(a - b - 0.1, 1), round(a - b + 1, 1)], 3)
        if r: out.append(r)
    # 小数乘
    for _ in range(1500):
        a = round(random.uniform(1, 20), 1)
        b = random.randint(2, 9)
        r = make(f"{a} × {b} = ?", round(a * b, 1), [round(a * b + 0.1, 1), round(a * b - 0.1, 1), round(a * b + 1, 1)], 3)
        if r: out.append(r)
    # 分数加减（同分母）
    for d in range(2, 15):
        for n1 in range(1, d):
            n2 = random.randint(1, d - n1)
            r = make(f"{n1}/{d} + {n2}/{d} = ?", f"{n1 + n2}/{d}", [f"{n1 + n2}/{d * 2}", f"{n1 * n2}/{d}", f"{n1 + n2 + 1}/{d}"], 3, "同分母分数相加，分母不变、分子相加")
            if r: out.append(r)
    # 简易方程
    for _ in range(3600):
        x = random.randint(2, 20)
        a = random.randint(2, 9)
        b = random.randint(1, 20)
        r = make(f"解方程：{a}x + {b} = {a * x + b}，x = ?", x, [x + 1, x - 1, a * x], 3, "两边先减常数项，再除以系数")
        if r: out.append(r)
    # 因数倍数
    for _ in range(500):
        n = random.randint(4, 60)
        c = len([i for i in range(1, n + 1) if n % i == 0])
        r = make(f"{n} 一共有多少个因数？", c, [c + 1, c - 1, c + 2], 3)
        if r: out.append(r)
    # 长方体体积
    for _ in range(1000):
        a, b, c = random.randint(2, 15), random.randint(2, 15), random.randint(2, 15)
        r = make(f"长 {a} 分米、宽 {b} 分米、高 {c} 分米的长方体，体积是多少立方分米？", a * b * c,
                 [2 * (a * b + a * c + b * c), a * b, a + b + c], 3, "体积 = 长 × 宽 × 高")
        if r: out.append(r)
    return out


# ---------------- 六年级 ----------------
def g6():
    out = []
    # 分数乘除
    for _ in range(6000):
        a1 = random.randint(1, 5)
        b1 = random.randint(a1 + 1, 10)
        a2 = random.randint(1, 5)
        b2 = random.randint(a2 + 1, 10)
        num, den = a1 * a2, b1 * b2
        g0 = math.gcd(num, den)
        num, den = num // g0, den // g0
        right = str(num) if den == 1 else f"{num}/{den}"
        raw = a1 * a2 / (b1 * b2)
        r = make(f"{a1}/{b1} × {a2}/{b2} = ?（结果化成最简分数）", right,
                 [f"{num + 1}/{den}", f"{num}/{den + 1}", f"{a1 + a2}/{b1 + b2}",
                  (f"{num}/{den}" if den != 1 else "1")], 3, "分子乘分子，分母乘分母，最后约分")
        if r: out.append(r)
    # 除法转乘法
    for _ in range(3200):
        a1 = random.randint(1, 5)
        b1 = random.randint(a1 + 1, 9)
        a2 = random.randint(1, 6)
        b2 = random.randint(a2 + 1, 9)
        num, den = a1 * b2, b1 * a2
        g0 = math.gcd(num, den)
        num, den = num // g0, den // g0
        right = str(num) if den == 1 else f"{num}/{den}"
        r = make(f"{a1}/{b1} ÷ {a2}/{b2} = ?（结果化成最简分数）", right,
                 [f"{num + 1}/{den}", f"{num}/{den + 1}", f"{a1 * a2}/{b1 * b2}"], 3,
                 "除以一个分数，等于乘它的倒数")
        if r: out.append(r)
    # 百分数
    for p in (10, 15, 20, 25, 30, 40, 50, 60, 75, 80, 90, 5, 35, 45, 55, 65, 70, 85, 95, 12):
        for base in range(100, 1001, 50):
            r = make(f"{base} 的 {p}% 是多少？", base * p // 100, [base * p // 100 + 10, base * p // 200, base / 100], 3,
                     f"{p}% = {p}/100")
            if r: out.append(r)
    # 圆的周长面积
    for r0 in range(2, 31):
        r_ = make(f"半径 {r0} 厘米的圆，周长是多少厘米？（π 取 3.14）", round(2 * 3.14 * r0, 2),
                  [round(3.14 * r0 * r0, 2), round(3.14 * r0, 2), round(2 * 3.14 * r0 + 3, 2)], 3, "圆周长 = 2πr")
        if r_: out.append(r_)
        r_ = make(f"半径 {r0} 厘米的圆，面积是多少平方厘米？（π 取 3.14）", round(3.14 * r0 * r0, 2),
                  [round(2 * 3.14 * r0, 2), round(3.14 * r0, 2), round(3.14 * r0 * r0 + 10, 2)], 3, "圆面积 = πr²")
        if r_: out.append(r_)
    # 比的化简
    for _ in range(4000):
        g = random.randint(2, 20)
        a, b = g * random.randint(1, 20), g * random.randint(1, 20)
        if a == b:
            continue
        gg = math.gcd(a, b)
        r = make(f"把比 {a} : {b} 化成最简整数比", f"{a // gg} : {b // gg}",
                 [f"{a} : {b}", f"{a // 2} : {b // 2}", f"{a // gg + 1} : {b // gg}"], 3, "前后项同时除以最大公因数")
        if r: out.append(r)
    # 圆柱体积
    for _ in range(2600):
        r0 = random.randint(2, 16)
        h = random.randint(2, 25)
        r = make(f"底面半径 {r0} 分米、高 {h} 分米的圆柱，体积是多少立方分米？（π 取 3.14）",
                 round(3.14 * r0 * r0 * h, 2), [round(3.14 * r0 * h, 2), round(2 * 3.14 * r0 * h, 2), round(3.14 * r0 * r0 * h + 10, 2)], 3,
                 "圆柱体积 = πr²h")
        if r: out.append(r)
    # 折扣
    for _ in range(2000):
        price = random.randrange(20, 501, 10)
        z = random.randint(5, 9)
        now = price * z // 10
        r = make(f"一件商品原价 {price} 元，打 {z} 折出售，现价多少元？", now,
                 [price * z // 100, price - z, price * (10 - z) // 10], 3, "打几折就是按原价的百分之几十出售")
        if r: out.append(r)
    # 异分母分数加法
    for _ in range(6000):
        b1 = random.randint(2, 9)
        b2 = random.randint(2, 9)
        a1 = random.randint(1, b1 - 1)
        a2 = random.randint(1, b2 - 1)
        den = b1 * b2 // math.gcd(b1, b2)
        num = a1 * (den // b1) + a2 * (den // b2)
        g0 = math.gcd(num, den)
        num, den = num // g0, den // g0
        right = str(num) if den == 1 else f"{num}/{den}"
        r = make(f"{a1}/{b1} + {a2}/{b2} = ?（结果化成最简分数）", right,
                 [f"{a1 + a2}/{b1 + b2}", f"{num + 1}/{den}", f"{num}/{den + 1}"], 3, "先通分再相加")
        if r: out.append(r)
    # 解比例
    for _ in range(1000):
        a = random.randint(2, 9)
        b = random.randint(2, 9)
        k = random.randint(2, 6)
        c = a * k
        x = c * b // a
        r = make(f"解比例：{a} : {b} = {c} : x，x = ?", x, [x + b, x - b, x * 2], 3, "内项积 = 外项积")
        if r: out.append(r)
    # 圆柱表面积
    for _ in range(2000):
        r0 = random.randint(2, 16)
        h = random.randint(2, 20)
        s = round(2 * 3.14 * r0 * r0 + 2 * 3.14 * r0 * h, 2)
        r = make(f"底面半径 {r0} 分米、高 {h} 分米的圆柱，表面积是多少平方分米？（π 取 3.14）", s,
                 [round(3.14 * r0 * r0 + 2 * 3.14 * r0 * h, 2), round(2 * 3.14 * r0 * h, 2), round(s + 10, 2)], 3,
                 "表面积 = 两个底面积 + 侧面积")
        if r: out.append(r)
    # 圆锥体积
    for _ in range(2000):
        r0 = random.randint(2, 16)
        h = random.choice([3, 6, 9, 12, 15])
        v = round(3.14 * r0 * r0 * h / 3, 2)
        r = make(f"底面半径 {r0} 分米、高 {h} 分米的圆锥，体积是多少立方分米？（π 取 3.14）", v,
                 [round(3.14 * r0 * r0 * h, 2), round(v * 2, 2), round(v + 10, 2)], 3, "圆锥体积 = 底面积 × 高 ÷ 3")
        if r: out.append(r)
    # 百分数应用
    for _ in range(900):
        base = random.choice([100, 200, 300, 400, 500, 600, 800])
        p = random.choice([5, 10, 15, 20, 25, 30, 40])
        r = make(f"某数比 {base} 多 {p}%，这个数是多少？", round(base * (1 + p / 100), 2),
                 [base * p / 100, base * (1 - p / 100), base + p], 3, "比原数多 p%，用原数乘 (1 + p%)")
        if r: out.append(r)
    # 已知周长求半径
    for r0 in range(2, 22):
        c = round(2 * 3.14 * r0, 2)
        r = make(f"一个圆的周长是 {c} 厘米，半径是多少厘米？（π 取 3.14）",
                 round(c / (2 * 3.14), 1),
                 [round(c / 3.14, 1), round(c / (2 * 3.14) + 1, 1), round(c / (2 * 3.14) - 1, 1)], 3,
                 "半径 = 周长 ÷ (2π)")
        if r: out.append(r)
    # 分数应用题
    for _ in range(1500):
        total = random.choice([60, 80, 120, 180, 240, 300, 400, 500, 600])
        d = random.choice([2, 3, 4, 5, 6, 8, 10])
        if total % d:
            continue
        r = make(f"一根 {total} 米长的绳子，用去全长的 1/{d}，用去多少米？", total // d,
                 [total // d + 1, total - total // d, total * d], 3, "求一个数的几分之几，用乘法")
        if r: out.append(r)
    # 成正比例的判断（数值题）
    for _ in range(900):
        a = random.randint(2, 9)
        b = random.randint(2, 9)
        k = random.randint(2, 6)
        r = make(f"若 {a} : {b} 与 x : {b * k} 能组成比例，x = ?", a * k, [a * k + a, a + b, b * k], 3,
                 "内项积 = 外项积")
        if r: out.append(r)
    # 分数乘整数
    for _ in range(3000):
        d = random.randint(2, 12)
        n0 = random.randint(1, d - 1)
        k = random.randint(2, 9)
        num = n0 * k
        g0 = math.gcd(num, d)
        num, den = num // g0, d // g0
        right = str(num) if den == 1 else f"{num}/{den}"
        r = make(f"{n0}/{d} × {k} = ?（结果化成最简分数）", right,
                 [f"{num + 1}/{den}", f"{num}/{den + 1}", f"{n0 * k}/{d * k}"], 3,
                 "分子乘整数，能约分先约分")
        if r: out.append(r)
    # 同分母分数比大小
    for d in range(3, 18):
        for n1 in range(1, d):
            n2 = random.randint(1, d - 1)
            if n1 == n2:
                continue
            r = make(f"比较大小：{n1}/{d} ○ {n2}/{d}", ">" if n1 > n2 else "<",
                     ["<", ">", "=", "无法比较"], 3, "分母相同，分子大的分数就大")
            if r: out.append(r)
    # 百分数化小数
    for p in range(1, 100):
        r = make(f"{p}% 化成小数是多少？", round(p / 100, 2), [round(p / 1000, 3), p, round(p / 10, 1)], 3,
                 "百分数化小数，除以 100")
        if r: out.append(r)
    # 小数化百分数
    for p in (0.1, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.75, 0.8, 0.9, 1.2, 1.5):
        r = make(f"{p} 化成百分数是多少？", f"{int(round(p * 100))}%",
                 [f"{int(round(p * 10))}%", f"{int(round(p * 100)) * 10}%", f"{int(round(p * 1000))}%"], 2,
                 "小数化百分数，乘以 100 再加百分号")
        if r: out.append(r)
    # 已知部分求整体
    for _ in range(3000):
        p = random.choice([10, 20, 25, 50])
        base = random.choice([50, 100, 200, 300, 400, 500, 800, 1000])
        part = base * p // 100
        r = make(f"一个数的 {p}% 是 {part}，这个数是多少？", base,
                 [part, part * 2, base // 2, base + 100], 3, "部分 ÷ 百分率 = 整体")
        if r: out.append(r)
    # 按比例分配
    for _ in range(3000):
        a = random.randint(1, 5)
        b = random.randint(1, 5)
        if a == b:
            continue
        unit = random.randint(2, 20)
        total = (a + b) * unit
        small = min(a, b) * unit
        big = max(a, b) * unit
        r = make(f"把 {total} 按 {a} : {b} 分成两份，较少的一份是多少？", small,
                 [big, unit, total], 3, "先求一份是多少，再乘份数")
        if r: out.append(r)
    # 已知几分之几求整体
    for _ in range(2500):
        total = random.choice([60, 80, 120, 180, 240, 300, 360, 400, 500, 600, 720, 800])
        d = random.choice([2, 3, 4, 5, 6, 8, 10])
        if total % d:
            continue
        part = total // d
        r = make(f"一个数的 1/{d} 是 {part}，这个数是多少？", total, [part, total // 2, total * 2], 3,
                 "部分 ÷ 1/" + str(d) + " = 整体")
        if r: out.append(r)
    # 圆柱侧面积
    for _ in range(2000):
        r0 = random.randint(2, 16)
        h = random.randint(2, 25)
        side = round(2 * 3.14 * r0 * h, 2)
        r = make(f"底面半径 {r0} 分米、高 {h} 分米的圆柱，侧面积是多少平方分米？（π 取 3.14）", side,
                 [round(3.14 * r0 * r0, 2), round(3.14 * r0 * h, 2), round(side + 10, 2)], 3,
                 "侧面积 = 底面周长 × 高 = 2πrh")
        if r: out.append(r)
    # 直径与半径
    for dd in range(4, 82, 2):
        r = make(f"直径 {dd} 厘米的圆，半径是多少厘米？", dd // 2, [dd * 2, dd, dd // 2 + 1, dd // 4], 1,
                 "半径 = 直径 ÷ 2")
        if r: out.append(r)
    # 半圆周长
    for r0 in range(2, 40):
        c = round(3.14 * r0 + 2 * r0, 2)
        r = make(f"半径 {r0} 厘米的半圆，周长是多少厘米？（π 取 3.14）", c,
                 [round(3.14 * r0, 2), round(2 * 3.14 * r0, 2), round(c + 10, 2)], 3, "半圆周长 = πr + 2r")
        if r: out.append(r)
    return out


GEN = {1: g1, 2: g2, 3: g3, 4: g4, 5: g5, 6: g6}
NAME = {1: "一年级", 2: "二年级", 3: "三年级", 4: "四年级", 5: "五年级", 6: "六年级"}

if __name__ == "__main__":
    outdir = r"D:\android-build\banks_out"
    os.makedirs(outdir, exist_ok=True)
    for g in range(1, 7):
        items = GEN[g]()
        # 去重（按题干）
        seen = set()
        uniq = []
        for it in items:
            if it["q"] in seen:
                continue
            seen.add(it["q"])
            uniq.append(it)
        path = os.path.join(outdir, f"math{g}.json")
        json.dump({"name": f"{NAME[g]} · 数学", "version": 1, "subject": "数学", "grade": g, "items": uniq},
                  open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(NAME[g], "数学", len(uniq), "题", "->", path)
