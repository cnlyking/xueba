import json, os
d = r"D:\android-build\banks_out"
for g in range(1, 7):
    tot = 0
    parts = []
    for sub, pre in (("数学", "math"), ("语文", "cn"), ("英语", "en")):
        p = os.path.join(d, f"{pre}{g}.json")
        if os.path.exists(p):
            n = len(json.load(open(p, encoding="utf-8"))["items"])
            tot += n
            parts.append(f"{sub}{n}")
    print(f"年级{g}: 合计 {tot}  ({' + '.join(parts)})")
