package com.yuhan.xueba

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var lockView: View? = null
    private lateinit var handler: Handler
    private var lastTick = 0L
    private var lastText = ""
    private var alarmShown = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        handler = Handler(Looper.getMainLooper())
        createChannels()
        startForeground(NOTI_ID, buildNotification("学习模式运行中"))
        lastTick = SystemClock.elapsedRealtime()
        registerScreenReceiver()
        handler.postDelayed(ticker, 3000)
        scheduleHeartbeat()
    }

    /** 熄屏、亮屏、解锁的瞬间重置计时基准，黑屏那段时间一秒都不能算 */
    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            lastTick = SystemClock.elapsedRealtime()
        }
    }

    private fun registerScreenReceiver() {
        try {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            registerReceiver(screenRx, f)
        } catch (e: Exception) {
            android.util.Log.e("GUARD", "屏幕状态监听注册失败", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastTick = SystemClock.elapsedRealtime()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private val ticker = object : Runnable {
        override fun run() {
            var next = 5000L
            try {
                next = runOnce()
            } catch (e: Throwable) {
                android.util.Log.e("GUARD", "tick failed", e)
            }
            handler.postDelayed(this, next)
        }
    }

    private fun runOnce(): Long {
        val now = SystemClock.elapsedRealtime()
        val delta = ((now - lastTick) / 1000L).toInt().coerceIn(0, 180)
        lastTick = now

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        // 熄屏或锁屏时一律不动：不计时、不拉锁屏页、不弹通知，等孩子解锁回来再算
        if (!pm.isInteractive || km.isKeyguardLocked) {
            hideLock()
            clearAlarm()
            return 5000L
        }

        val rem0 = App.db.remainingSec()
        // 已经用完就不再往「已用」里加；本 App 自己的界面在前台时也不计时，只算别的应用
        if (rem0 > 0 && !App.inForeground()) {
            App.db.addUsed(minOf(delta, rem0))
        }

        val rem = App.db.remainingSec()
        LockState.locked = rem <= 0
        // 答题页在前台时绝不能锁：这时还没结算加时长，一锁就把答题页盖住了
        val quizzing = App.isPausedForQuiz()

        if (rem <= 0 && !quizzing && !LockState.passed()) {
            // 每一轮都重新顶一次：孩子可能已经切到别的应用，上一次拉起来的界面早被盖住了
            launchLock()
            // 自己不在前台时才盖悬浮层；已经在锁屏页上就撤掉，别压住按钮
            if (!App.inForeground()) showLock() else hideLock()
            notifyAlarm()
        } else {
            hideLock()
            clearAlarm()
        }

        val text = if (rem <= 0) "学习模式 · 时间用完，该答题了"
        else "学习模式运行中 · 剩余 ${(rem + 59) / 60} 分钟"
        if (text != lastText) {
            lastText = text
            updateNotification(text)
        }

        // 快到点或者已经到点时提高心跳频率，做到一秒内反应
        return if (rem <= 0) 800L else if (rem <= 60) 1000L else 5000L
    }

    /**
     * 把锁屏页顶到前台。两条路一起走：
     * 1. 借助辅助功能服务启动界面（系统绑定的特权服务，被厂商拦的概率低）
     * 2. 直接由本服务启动（有悬浮窗权限，Android 官方豁免后台启动限制）
     * 都不行还有悬浮层兜着。
     */
    private fun launchLock() {
        val now = System.currentTimeMillis()
        if (now - LockState.lastLaunchAt < 600L) return
        LockState.lastLaunchAt = now

        // 最快的一路：直接把自己的任务提到最前面，不走 startActivity，绕开后台启动限制
        if (moveLockTaskToFront()) {
            handler.postDelayed({ if (App.inForeground()) hideLock() }, 500)
            return
        }

        val target = Intent(this, LockActivity::class.java)
        target.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
        )

        var started = false
        UninstallGuardService.instance?.let { acc ->
            try {
                acc.startActivity(target)
                started = true
                android.util.Log.d("GUARD", "通过辅助功能拉起锁屏页")
            } catch (e: Exception) {
                android.util.Log.e("GUARD", "辅助功能拉起失败", e)
            }
        }
        if (!started) {
            try {
                startActivity(target)
                started = true
            } catch (e: Exception) {
                android.util.Log.e("GUARD", "拉起锁屏页失败", e)
            }
        }

        // 真起来了就把悬浮层撤掉，让锁屏页露出来
        handler.postDelayed({ if (App.inForeground()) hideLock() }, 1200)
    }

    private fun moveLockTaskToFront(): Boolean {
        return try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            for (t in am.appTasks) {
                val base = t.taskInfo.baseIntent?.component?.className ?: continue
                if (base.endsWith("LockActivity")) {
                    t.moveToFront()
                    return true
                }
            }
            false
        } catch (e: Throwable) {
            android.util.Log.e("GUARD", "moveToFront 失败", e)
            false
        }
    }

    private fun showLock() {
        val cur = lockView
        if (cur != null && cur.isAttachedToWindow) return
        if (cur != null) {
            try { wm.removeView(cur) } catch (e: Exception) { }
            lockView = null
        }
        if (!Settings.canDrawOverlays(this)) return

        val view = LayoutInflater.from(this).inflate(R.layout.overlay_lock, null)
        view.findViewById<View>(R.id.btnGoQuiz).setOnClickListener {
            hideLock()
            try {
                startActivity(
                    Intent(this, QuizActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            } catch (e: Exception) {
            }
        }
        view.findViewById<View>(R.id.tvLockFix).setOnClickListener {
            hideLock()
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .putExtra("open_bg_popup", true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            } catch (e: Exception) {
            }
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.OPAQUE
        )
        try {
            wm.addView(view, lp)
            lockView = view
        } catch (e: Exception) {
            lockView = null
        }
    }

    private fun hideLock() {
        val v = lockView ?: return
        lockView = null
        try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val normal = NotificationChannel(CHANNEL, "学习模式", NotificationManager.IMPORTANCE_LOW)
            normal.setShowBadge(false)
            nm.createNotificationChannel(normal)
            val alarm = NotificationChannel(ALARM_CHANNEL, "时间到提醒", NotificationManager.IMPORTANCE_HIGH)
            alarm.setShowBadge(true)
            nm.createNotificationChannel(alarm)
        }
    }

    /** 时间到的时候补一条全屏通知：万一界面被厂商挡住，锁屏状态下也能弹出来 */
    private fun notifyAlarm() {
        if (alarmShown) return
        alarmShown = true
        try {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            else
                PendingIntent.FLAG_UPDATE_CURRENT
            val pi = PendingIntent.getActivity(
                this, 3,
                Intent(this, LockActivity::class.java).addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                ),
                flags
            )
            val n = NotificationCompat.Builder(this, ALARM_CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle("成为学霸 · 时间到了")
                .setContentText("答一组题就能接着用")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setFullScreenIntent(pi, true)
                .setContentIntent(pi)
                .build()
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(ALARM_ID, n)
        } catch (e: Exception) {
        }
    }

    private fun clearAlarm() {
        if (!alarmShown) return
        alarmShown = false
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(ALARM_ID)
        } catch (e: Exception) {
        }
    }

    private fun buildNotification(text: String): Notification {
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        else
            PendingIntent.FLAG_UPDATE_CURRENT
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), flags
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("成为学霸")
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pi)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTI_ID, buildNotification(text))
        } catch (e: Exception) {
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // 被划掉后自己回来
        scheduleRestart()
        try {
            val i = Intent(this, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
        } catch (e: Exception) {
        }
        super.onTaskRemoved(rootIntent)
    }

    private fun scheduleRestart() {
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            else
                PendingIntent.FLAG_UPDATE_CURRENT
            val pi = PendingIntent.getBroadcast(
                this, 1, Intent(this, BootReceiver::class.java).setAction(ACTION_RESTART), flags
            )
            am.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 3000, pi)
        } catch (e: Exception) {
        }
    }

    /** 十分钟一次心跳，被系统清掉时由广播把服务再拉起来 */
    private fun scheduleHeartbeat() {
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            else
                PendingIntent.FLAG_UPDATE_CURRENT
            val pi = PendingIntent.getBroadcast(
                this, 2, Intent(this, BootReceiver::class.java).setAction(ACTION_RESTART), flags
            )
            am.setInexactRepeating(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + 10 * 60 * 1000L,
                10 * 60 * 1000L,
                pi
            )
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        hideLock()
        clearAlarm()
        try { unregisterReceiver(screenRx) } catch (e: Exception) { }
        scheduleRestart()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "study_guard"
        const val ALARM_CHANNEL = "study_alarm"
        const val NOTI_ID = 1001
        const val ALARM_ID = 1002
        const val ACTION_RESTART = "com.yuhan.xueba.RESTART_GUARD"
    }
}
