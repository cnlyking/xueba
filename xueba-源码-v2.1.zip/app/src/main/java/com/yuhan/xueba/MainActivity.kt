package com.yuhan.xueba

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.Intent
import android.content.Context.DEVICE_POLICY_SERVICE
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvRemain: TextView
    private lateinit var tvRemainSub: TextView
    private lateinit var tvStat: TextView
    private lateinit var tvMistake: TextView
    private lateinit var tvHint: TextView
    private lateinit var tvGuard: TextView
    private lateinit var btnStart: android.widget.Button

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 5000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvRemain = findViewById(R.id.tvRemain)
        tvRemainSub = findViewById(R.id.tvRemainSub)
        tvStat = findViewById(R.id.tvStat)
        tvMistake = findViewById(R.id.tvMistake)
        tvHint = findViewById(R.id.tvHint)
        tvGuard = findViewById(R.id.tvGuard)
        btnStart = findViewById(R.id.btnStart)

        btnStart.setOnClickListener { startQuiz() }
        findViewById<android.view.View>(R.id.btnSettings).setOnClickListener {
            Pin.require(this) {
                startActivity(Intent(this, SettingsActivity::class.java))
            }
        }
        findViewById<android.view.View>(R.id.btnHelp).setOnClickListener { showCopyright() }
        findViewById<android.view.View>(R.id.tvGuard).setOnClickListener { showGuardDialog() }
        findViewById<android.view.View>(R.id.tvExit).setOnClickListener { askExit() }

        ensureService()
        Guard.schedule(this)

        if (!Pin.isSet()) {
            // 没设密码就先别进主页，统一走设置页，设好才回来，避免一启动就被绕过去
            startActivity(Intent(this, SetupPinActivity::class.java))
            finish()
            return
        }
        if (!Settings.canDrawOverlays(this)) askOverlayPermission()
        askNotifications()

        // 从锁屏遮罩上「没自动跳过来」点进来的
        if (intent?.getBooleanExtra("open_bg_popup", false) == true) {
            handler.postDelayed({ openBackgroundPopup() }, 1200)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.getBooleanExtra("open_bg_popup", false) == true) {
            handler.postDelayed({ openBackgroundPopup() }, 400)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onBackPressed() {
        askExit()
    }

    /** 退出要家长密码 */
    private fun askExit() {
        if (!Pin.isSet()) {
            Toast.makeText(this, "先在设置里设好家长密码，才能退出", Toast.LENGTH_SHORT).show()
            return
        }
        Pin.require(this) {
            Toast.makeText(this, "已退出（学习计时还在后台跑着）", Toast.LENGTH_SHORT).show()
            finishAffinity()
        }
    }

    private fun showCopyright() {
        val vn = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        AlertDialog.Builder(this)
            .setTitle("关于")
            .setMessage(
                "成为学霸 v$vn\n\n" +
                    "版权所有：钰涵爸爸\n\n" +
                    "本应用仅本地运行，不联网、不上传任何数据。\n" +
                    "题库、答题记录、错题本全部存在手机本地。"
            )
            .setPositiveButton("知道了", null)
            .show()
    }

    private fun showGuardDialog() {
        val admin = AdminReceiver.isActive(this)
        val battery = Guard.isIgnoringBattery(this)
        val acc = isGuardServiceOn()

        val items = arrayOf(
            if (admin) "关闭防卸载（设备管理）：已开启" else "开启防卸载（设备管理）：未开启",
            if (acc) "卸载拦截（辅助功能）：已开启" else "开启卸载拦截（辅助功能）：要密码才能卸",
            "时间到跳回前台：点这里开「后台弹出界面」",
            if (battery) "电池优化：已忽略（点这里看）" else "忽略电池优化：不然后台可能被清掉",
            "测一下：立刻把时间用完，看它跳不跳前台"
        )

        AlertDialog.Builder(this)
            .setTitle("后台与卸载保护")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> if (admin) disableAdmin() else enableAdmin()
                    1 -> openAccessibility()
                    2 -> openBackgroundPopup()
                    3 -> openBattery()
                    4 -> testLock()
                }
            }
            .setNegativeButton("关闭", null)
            .show()
    }

    /**
     * 当场验证「时间到跳前台」：把今天的可用时间一次扣光，锁屏页立刻出来；
     * 再按 Home 回桌面，几秒内应该自己跳回来。跳不回来就是后台启动被拦了。
     */
    private fun testLock() {
        AlertDialog.Builder(this)
            .setTitle("测一下跳前台")
            .setMessage(
                "会把你今天剩余的可用时间一次扣光，锁屏页立刻弹出来。\n\n" +
                    "弹出来之后按 Home 键回桌面，几秒内应该自己跳回来。\n" +
                    "跳不回来，就是「后台弹出界面」没开。\n\n" +
                    "测完想恢复：设置 → 清空今天的记录。"
            )
            .setPositiveButton("开始测") { _, _ ->
                App.db.addUsed(App.db.remainingSec() + 60)
                try {
                    startActivity(Intent(this, LockActivity::class.java))
                } catch (e: Exception) {
                }
                Toast.makeText(this, "已锁上。现在按 Home 去桌面，看它会不会自己跳回来", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    /** 华为/小米等厂商都有「后台弹出界面」开关，不打开的话时间到拉不回前台 */
    private fun openBackgroundPopup() {
        val comps = listOf(
            "com.huawei.systemmanager" to "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.optimize.process.ProtectActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.oplus.safecenter" to "com.oplus.safecenter.startupapp.StartupAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
        )
        for ((pkg, cls) in comps) {
            try {
                startActivity(
                    Intent().setComponent(android.content.ComponentName(pkg, cls))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                Toast.makeText(
                    this,
                    "找到「成为学霸」，把「后台弹出界面 / 自启动 / 关联启动」都打开",
                    Toast.LENGTH_LONG
                ).show()
                return
            } catch (e: Exception) {
            }
        }
        try {
            startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")
                )
            )
            Toast.makeText(this, "本机没有单独的开关页，在应用详情里把权限都放开", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "系统设置页打不开", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isGuardServiceOn(): Boolean {
        return try {
            val flat = Settings.Secure.getString(
                contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            flat.contains("com.yuhan.xueba/com.yuhan.xueba.UninstallGuardService") ||
                flat.contains("com.yuhan.xueba/.UninstallGuardService")
        } catch (e: Exception) {
            false
        }
    }

    private fun openAccessibility() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "在列表里找到「成为学霸」，把开关打开", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "系统没找到辅助功能设置页", Toast.LENGTH_LONG).show()
        }
    }

    private fun enableAdmin() {
        // 家长从 App 内主动开保护，系统页面上别弹自己的密码框
        GuardGate.passUntil = System.currentTimeMillis() + 120_000L
        try {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, AdminReceiver.component(this))
            i.putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "开启后卸载本应用需要先取消设备管理，防止孩子自己卸载"
            )
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "系统没找到设备管理页，请到设置里手动开", Toast.LENGTH_LONG).show()
        }
    }

    private fun disableAdmin() {
        Pin.require(this) {
            GuardGate.passUntil = System.currentTimeMillis() + 120_000L
            try {
                val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
                dpm.removeActiveAdmin(AdminReceiver.component(this))
                Toast.makeText(this, "防卸载已关闭", Toast.LENGTH_SHORT).show()
                refresh()
            } catch (e: Exception) {
            }
        }
    }

    private fun openBattery() {
        try {
            if (Guard.isIgnoringBattery(this)) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } else {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                Toast.makeText(this, "系统没找到电池优化设置页", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startQuiz() {
        if (App.db.bankCount() == 0) {
            Toast.makeText(this, "题库还在载入，稍等一下再点", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, QuizActivity::class.java))
    }

    private fun refresh() {
        val limit = App.db.earnLimitMin()
        val useCap = App.db.useLimitMin()
        val earnFull = App.db.earnLimitReached()
        val useOut = App.db.useLimitReached()
        val earned = App.db.earnedMin()
        val used = App.db.usedSec()
        val rem = App.db.remainingSec()
        val remMin = ((rem + 59) / 60)

        tvRemain.text = "剩余 $remMin 分钟"
        val avail = App.db.availableSec()
        tvRemainSub.text = "本次已攒 ${avail / 60} / $limit 分钟 · 已用 ${used / 60} / $useCap 分钟"

        val answered = App.db.answeredCount()
        val right = App.db.rightCount()
        val rate = if (answered > 0) "${right * 100 / answered}%" else "—"
        tvStat.text = "今日已答 $answered 题 · 正确率 $rate"

        val mistakes = App.db.mistakeCount()
        if (mistakes > 0) {
            tvMistake.visibility = android.view.View.VISIBLE
            tvMistake.text = if (mistakes >= 10) {
                "错题本 $mistakes 道，攒够 10 道了，下一组先把错的重新做一遍"
            } else {
                "错题本 $mistakes 道（满 10 道强制复习）"
            }
        } else {
            tvMistake.visibility = android.view.View.GONE
        }

        btnStart.text = when {
            mistakes >= 10 -> "复习错题（10 道）"
            rem <= 0 -> "先答题解锁时间"
            else -> "继续答题赚时长"
        }

        tvHint.text = when {
            mistakes >= 10 -> "错题攒够 10 道，先把错的过一遍，答对就从错题本移出去"
            useOut -> "今天手机已经用到 $useCap 分钟，到使用上限了，明天再来"
            rem <= 0 -> "时间用完了，答一组就能接着用"
            earnFull -> "这次已经攒满 $limit 分钟，用掉一些才能再攒，接着答只当巩固"
            else -> "还有 $remMin 分钟能用，用完会自动跳回来提醒你"
        }

        val accOn = isGuardServiceOn()
        val admin = if (AdminReceiver.isActive(this)) "防卸载已开启" else "防卸载未开启"
        val battery = if (Guard.isIgnoringBattery(this)) "已忽略电池优化" else "建议忽略电池优化"
        tvGuard.text = if (accOn)
            "卸载拦截已开启 · $admin\n$battery\n时间到会自动跳回前台\n点这里调整"
        else
            "⚠ 辅助功能没开：孩子能直接卸载\n点这里开启（要开辅助功能）"
    }

    private fun ensureService() {
        Guard.start(this)
    }

    private fun askNotifications() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
    }

    /** 先说明再引导去系统设置，不要一上来就跳走 */
    fun askOverlayPermission() {
        AlertDialog.Builder(this)
            .setTitle("还要一个权限")
            .setMessage("开启「显示在其他应用上层」后，时间一到 App 才有资格把自己弹到前台，同时还能全屏盖住别的应用。")
            .setPositiveButton("去开启") { _, _ ->
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) {
                    Toast.makeText(this, "系统没找到悬浮窗设置页，请到设置里手动开", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("稍后再说", null)
            .show()
    }
}
