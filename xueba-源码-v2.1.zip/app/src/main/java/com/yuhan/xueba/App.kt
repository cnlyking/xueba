package com.yuhan.xueba

import android.app.Activity
import android.app.Application
import android.os.Bundle

class App : Application() {

    companion object {
        lateinit var db: Db
            private set

        /** 当前处于前台的 Activity 数量 */
        var started = 0

        /** 当前最上层 Activity 的类名 */
        var current: String? = null

        fun inForeground(): Boolean = started > 0

        /** 答题页和家长设置页不计入使用时长 */
        fun isPausedForQuiz(): Boolean =
            current == "QuizActivity" || current == "SettingsActivity"
    }

    override fun onCreate() {
        super.onCreate()
        db = Db(this)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                started++
            }

            override fun onActivityStopped(activity: Activity) {
                started = (started - 1).coerceAtLeast(0)
            }

            override fun onActivityResumed(activity: Activity) {
                current = activity.javaClass.simpleName
            }

            override fun onActivityPaused(activity: Activity) {
                if (current == activity.javaClass.simpleName) current = null
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })

        BankIO.seed(this, db)
        Guard.schedule(this)
    }
}
