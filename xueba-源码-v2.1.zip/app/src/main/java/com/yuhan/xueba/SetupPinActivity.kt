package com.yuhan.xueba

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * 首次启动必须先过这一页。以前是弹对话框，页面还没稳住就弹，
 * 手快一点能直接摸进主界面；改成独立整页，没密码就没法往下走。
 */
class SetupPinActivity : AppCompatActivity() {

    private lateinit var etPin: EditText
    private lateinit var etPin2: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup_pin)

        etPin = findViewById(R.id.etPin)
        etPin2 = findViewById(R.id.etPin2)
        findViewById<android.view.View>(R.id.btnSave).setOnClickListener { save() }
    }

    private fun save() {
        val a = etPin.text.toString().trim()
        val b = etPin2.text.toString().trim()

        if (a.length !in 4..6 || a.toIntOrNull() == null) {
            Toast.makeText(this, "密码要 4–6 位数字", Toast.LENGTH_SHORT).show()
            etPin.requestFocus()
            return
        }
        if (a != b) {
            Toast.makeText(this, "两次输入不一致，再对一下", Toast.LENGTH_SHORT).show()
            etPin2.setText("")
            etPin2.requestFocus()
            return
        }

        App.db.setCfg("pin", a)
        // 写完立刻回读，确认真的落盘了再往下走
        if (App.db.cfg("pin", "") != a) {
            Toast.makeText(this, "密码没存上，再点一次", Toast.LENGTH_SHORT).show()
            return
        }

        Toast.makeText(this, "密码已保存，以后退出、改设置都要用它", Toast.LENGTH_LONG).show()
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun askNotifications() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            try {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1001)
            } catch (e: Exception) {
            }
        }
    }

    override fun onBackPressed() {
        Toast.makeText(this, "先设好家长密码才能用", Toast.LENGTH_SHORT).show()
    }
}
