package com.yuhan.xueba

import android.app.admin.DeviceAdminReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Context.DEVICE_POLICY_SERVICE
import android.app.admin.DevicePolicyManager

/** 激活后卸载要先取消激活，做不到一键卸载 */
class AdminReceiver : DeviceAdminReceiver() {

    override fun onDisableRequested(context: android.content.Context, intent: android.content.Intent): CharSequence {
        return "取消防卸载保护需要家长同意。\n如果是孩子本人操作，请先把手机交给家长。"
    }

    companion object {
        fun component(c: Context): ComponentName = ComponentName(c, AdminReceiver::class.java)

        fun isActive(c: Context): Boolean {
            return try {
                val dpm = c.getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
                dpm.isAdminActive(component(c))
            } catch (e: Exception) {
                false
            }
        }
    }
}
