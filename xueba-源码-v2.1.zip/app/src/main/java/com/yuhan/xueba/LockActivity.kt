package com.yuhan.xueba

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * 时间用完后的锁屏页。用真正的 Activity 而不是悬浮层：
 * 它能把界面顶到前台，用户在别的应用里也能被直接切回来。
 */
class LockActivity : AppCompatActivity() {

    private lateinit var tvSub: TextView
    private var asking = false
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }

        tvSub = findViewById(R.id.tvLockSub)
        findViewById<View>(R.id.btnGoQuiz).setOnClickListener { goQuiz() }
        findViewById<View>(R.id.btnParentExit).setOnClickListener { askPin() }
    }

    override fun onResume() {
        super.onResume()
        LockState.showing = true
        refresh()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        LockState.showing = false
        super.onPause()
    }

    override fun onDestroy() {
        LockState.showing = false
        super.onDestroy()
    }

    private fun refresh() {
        // 又攒出时间了，或者家长已经放行，这一页自己退
        if (App.db.remainingSec() > 0 || LockState.passed()) {
            finish()
            return
        }
        val answered = App.db.answeredCount()
        val earned = App.db.earnedMin()
        val earnCap = App.db.earnLimitMin()
        val useCap = App.db.useLimitMin()
        val useOut = App.db.useLimitReached()
        val earnFull = App.db.earnLimitReached()
        val canQuiz = !useOut && !earnFull

        tvSub.text = when {
            useOut -> "今天手机已经用了 $useCap 分钟，到使用上限了\n明天再来，或者让家长在设置里调高"
            else -> "今天答了 $answered 题，手上没时长了\n答一组最多攒 $earnCap 分钟，接着用"
        }
        findViewById<View>(R.id.btnGoQuiz).visibility = if (canQuiz) View.VISIBLE else View.GONE
    }

    private fun goQuiz() {
        if (App.db.bankCount() == 0) {
            Toast.makeText(this, "题库是空的，让家长先导入题库", Toast.LENGTH_LONG).show()
            return
        }
        try {
            startActivity(Intent(this, QuizActivity::class.java))
        } catch (e: Exception) {
        }
    }

    /** 想切走、想退出，都得输家长密码；输对了放行一段时间 */
    private fun askPin() {
        if (asking) return
        if (LockState.passed()) {
            finish()
            goHome()
            return
        }
        if (!Pin.isSet()) {
            AlertDialog.Builder(this)
                .setTitle("还没设家长密码")
                .setMessage("先设一个家长密码，设完就能离开；以后要退出都得用它。")
                .setPositiveButton("现在设置") { _, _ ->
                    Pin.createNew(this) {
                        val passMin = App.db.cfgInt("lockPassMin", 10)
                        LockState.passFor(passMin)
                        Toast.makeText(this, "密码已保存，已放行 $passMin 分钟", Toast.LENGTH_SHORT).show()
                        finish()
                        goHome()
                    }
                }
                .setNegativeButton("取消", null)
                .show()
            return
        }
        asking = true
        Pin.require(this) {
            asking = false
            val passMin = App.db.cfgInt("lockPassMin", 10)
            LockState.passFor(passMin)
            Toast.makeText(this, "已放行 $passMin 分钟，到点再锁", Toast.LENGTH_SHORT).show()
            finish()
            goHome()
        }
    }

    private fun goHome() {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        } catch (e: Exception) {
        }
    }

    override fun onBackPressed() {
        // 返回不是离开，是弹密码
        askPin()
    }
}
