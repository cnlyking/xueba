package com.yuhan.xueba

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object BankIO {

    /** 从 assets/banks 里导入内置题库，只在第一次运行时做一次 */
    fun seed(ctx: Context, db: Db) {
        Thread {
            try {
                if (db.cfg("seeded", "0") == "1") return@Thread
                val files = ctx.assets.list("banks") ?: emptyArray()
                var total = 0
                for (name in files) {
                    val text = ctx.assets.open("banks/$name").bufferedReader().use { it.readText() }
                    total += importJson(db, text, name)
                }
                db.setCfg("seeded", "1")
                db.setCfg("seedCount", total)
            } catch (e: Exception) {
                // 题库导入失败不阻塞使用，用户可以手动导入
            }
        }.start()
    }

    /** 导入一份 version:2 格式题库，返回新插入的题数 */
    fun importJson(db: Db, text: String, hint: String = ""): Int {
        val root = JSONObject(text)
        val name = root.optString("name", "")
        val subject = guessSubject(if (name.isNotBlank()) name else hint)
        val arr = root.optJSONArray("items") ?: return 0
        val list = ArrayList<Question>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            Question.parse(o)?.let { list.add(it) }
        }
        return db.addQuestions(list, subject)
    }

    /** 导出全部题目为 version:2 格式 */
    fun exportJson(db: Db): String {
        val items = JSONArray()
        for (raw in db.allRaw()) {
            try {
                items.put(JSONObject(raw))
            } catch (e: Exception) {
            }
        }
        val root = JSONObject()
        root.put("version", 2)
        root.put("name", "题了个题导出题库")
        root.put("items", items)
        return root.toString()
    }

    private fun guessSubject(s: String): String = when {
        s.contains("语文") -> "语文"
        s.contains("数学") -> "数学"
        s.contains("英语") -> "英语"
        else -> "综合"
    }
}
