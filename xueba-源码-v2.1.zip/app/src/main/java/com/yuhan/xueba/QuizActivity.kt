package com.yuhan.xueba

import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.random.Random

class QuizActivity : AppCompatActivity() {

    private val items = ArrayList<Question>()
    private var idx = 0
    private var right = 0
    private var answered = 0
    private var starSum = 0
    private var streak = 0
    private var submitted = false
    private var mode = "group"
    private var reviewMode = false

    private lateinit var tvIndex: TextView
    private lateinit var tvStar: TextView
    private lateinit var tvType: TextView
    private lateinit var tvQuestion: TextView
    private lateinit var optionBox: LinearLayout
    private lateinit var resultCard: LinearLayout
    private lateinit var tvResult: TextView
    private lateinit var tvAnswer: TextView
    private lateinit var tvTip: TextView
    private lateinit var btnSubmit: View
    private lateinit var btnNext: View
    private lateinit var pb: android.widget.ProgressBar
    private lateinit var quizPanel: View
    private lateinit var resultPanel: View
    private lateinit var tvResTitle: TextView
    private lateinit var tvResStats: TextView
    private lateinit var tvResReward: TextView

    private var radioGroup: RadioGroup? = null
    private var checkBoxes = ArrayList<CheckBox>()
    private var editInput: EditText? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var praiseLayer: View? = null

    /** 答对的夸奖话，随机抽一句，连着答对也不会腻 */
    private val praises = listOf(
        "真棒！答对啦",
        "太厉害了！",
        "这道题难不倒你",
        "思路很清楚",
        "漂亮，又对一道",
        "就是这个感觉，继续",
        "给你点个赞",
        "脑袋转得真快"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        tvIndex = findViewById(R.id.tvIndex)
        tvStar = findViewById(R.id.tvStar)
        tvType = findViewById(R.id.tvType)
        tvQuestion = findViewById(R.id.tvQuestion)
        optionBox = findViewById(R.id.optionBox)
        resultCard = findViewById(R.id.resultCard)
        tvResult = findViewById(R.id.tvResult)
        tvAnswer = findViewById(R.id.tvAnswer)
        tvTip = findViewById(R.id.tvTip)
        btnSubmit = findViewById(R.id.btnSubmit)
        btnNext = findViewById(R.id.btnNext)
        pb = findViewById(R.id.pb)
        quizPanel = findViewById(R.id.quizPanel)
        resultPanel = findViewById(R.id.resultPanel)
        tvResTitle = findViewById(R.id.tvResTitle)
        tvResStats = findViewById(R.id.tvResStats)
        tvResReward = findViewById(R.id.tvResReward)

        mode = App.db.cfg("mode", "group")

        btnSubmit.setOnClickListener { submit() }
        btnNext.setOnClickListener { nextQuestion() }
        findViewById<View>(R.id.btnSettings).setOnClickListener {
            Pin.require(this) {
                startActivity(Intent(this, SettingsActivity::class.java))
            }
        }
        findViewById<View>(R.id.btnAgain).setOnClickListener {
            resultPanel.visibility = View.GONE
            quizPanel.visibility = View.VISIBLE
            buildGroup()
        }
        findViewById<View>(R.id.btnBack).setOnClickListener { goBackground() }

        initTts()
        buildGroup()
    }

    private fun buildGroup() {
        items.clear()
        idx = 0
        right = 0
        answered = 0
        starSum = 0
        streak = 0

        val mistakes = App.db.mistakeCount()
        reviewMode = mistakes >= 10

        if (reviewMode) {
            // 错题攒够 10 道，这组只做错题
            items.addAll(App.db.takeMistakes(10))
            Toast.makeText(this, "错题本攒了 $mistakes 道，这组先把错的重新做一遍", Toast.LENGTH_LONG).show()
        } else {
            val size = App.db.cfgInt("groupSize", 8)
            items.addAll(App.db.takeQuestions(size, null))

            val th = App.db.cfgInt("mistakeTh", 3)
            if (mistakes >= th) {
                val extra = App.db.cfgInt("mistakeExtra", 3)
                for (q in App.db.takeMistakes(extra)) {
                    if (items.none { it.id == q.id }) items.add(q)
                }
            }
        }

        if (items.isEmpty()) {
            Toast.makeText(this, "题库是空的，请家长先导入题库", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        render()
    }

    private fun render() {
        submitted = false
        radioGroup = null
        checkBoxes.clear()
        editInput = null

        val q = items[idx]
        tvIndex.text = "第 ${idx + 1} / ${items.size} 题"
        tvStar.text = "★".repeat(q.star)
        tvType.text = when (q.type) {
            "multiple" -> "多选题"
            "boolean" -> "判断题"
            "text" -> "填空题"
            "subjective" -> "解答题"
            else -> "单选题"
        }
        tvQuestion.text = q.text
        pb.progress = idx * 100 / items.size

        resultCard.visibility = View.GONE
        btnSubmit.visibility = View.VISIBLE
        btnNext.visibility = View.GONE

        optionBox.removeAllViews()
        when (q.type) {
            "multiple" -> buildCheckBoxes(q)
            "text", "subjective" -> buildInput(q)
            else -> buildRadio(q)
        }
    }

    private fun buildRadio(q: Question) {
        val rg = RadioGroup(this)
        rg.orientation = LinearLayout.VERTICAL
        q.options.forEachIndexed { i, text ->
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = if (q.type == "boolean") text else "${'A' + i}. $text"
            rb.textSize = 17f
            rb.setPadding(0, dp(8), 0, dp(8))
            rg.addView(rb)
        }
        optionBox.addView(rg)
        radioGroup = rg
    }

    private fun buildCheckBoxes(q: Question) {
        q.options.forEachIndexed { i, text ->
            val cb = CheckBox(this)
            cb.text = "${'A' + i}. $text"
            cb.textSize = 17f
            cb.setPadding(0, dp(8), 0, dp(8))
            optionBox.addView(cb)
            checkBoxes.add(cb)
        }
    }

    private fun buildInput(q: Question) {
        val et = EditText(this)
        et.hint = if (q.type == "subjective") "把答案写在这里" else "填答案"
        et.textSize = 17f
        if (q.type == "subjective") {
            et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            et.minLines = 3
            et.gravity = android.view.Gravity.TOP or android.view.Gravity.START
        } else {
            et.inputType = InputType.TYPE_CLASS_TEXT
        }
        optionBox.addView(et)
        editInput = et
    }

    private fun submit() {
        if (submitted) return
        val q = items[idx]

        val sel = ArrayList<Int>()
        when (q.type) {
            "multiple" -> checkBoxes.forEachIndexed { i, cb -> if (cb.isChecked) sel.add(i) }
            "text", "subjective" -> {}
            else -> {
                val rg = radioGroup ?: return
                val checkedId = rg.checkedRadioButtonId
                if (checkedId == -1) {
                    Toast.makeText(this, "先选一个再提交", Toast.LENGTH_SHORT).show()
                    return
                }
                val pos = rg.indexOfChild(rg.findViewById(checkedId))
                if (pos >= 0) sel.add(pos)
            }
        }

        if (q.type == "multiple" && sel.isEmpty()) {
            Toast.makeText(this, "至少选一个", Toast.LENGTH_SHORT).show()
            return
        }
        val input = editInput?.text?.toString()

        if (q.type == "subjective") {
            submitted = true
            showSubjective(q)
            return
        }

        val ok = q.judge(sel, input)
        submitted = true
        answered++
        if (ok) {
            right++
            streak++
            starSum += App.db.cfgInt("star${q.star}", 1)
            App.db.removeMistake(q.id)
        } else {
            streak = 0
            App.db.addMistake(q.id)
        }
        showResult(q, ok)
    }

    private fun showResult(q: Question, ok: Boolean) {
        disableOptions()
        resultCard.visibility = View.VISIBLE
        tvResult.text = if (ok) "答对了" else "答错了"
        tvResult.setTextColor(ContextCompat.getColor(this, if (ok) R.color.ok else R.color.bad))
        tvAnswer.text = "正确答案：${q.answerText()}"
        val showTip = App.db.cfgBool("showTip", true)
        tvTip.visibility = if (showTip && q.tip.isNotBlank()) View.VISIBLE else View.GONE
        tvTip.text = q.tip
        btnSubmit.visibility = View.GONE
        btnNext.visibility = View.VISIBLE
        if (ok) praise()
    }

    private fun showSubjective(q: Question) {
        disableOptions()
        resultCard.visibility = View.VISIBLE
        tvResult.text = "对照参考答案自查"
        tvResult.setTextColor(ContextCompat.getColor(this, R.color.primary))
        tvAnswer.text = if (q.modelAnswer.isNotBlank()) q.modelAnswer else "（这题没配参考答案）"
        val showTip = App.db.cfgBool("showTip", true)
        tvTip.visibility = if (showTip && q.tip.isNotBlank()) View.VISIBLE else View.GONE
        tvTip.text = q.tip
        btnSubmit.visibility = View.GONE
        btnNext.visibility = View.VISIBLE
    }

    private fun disableOptions() {
        radioGroup?.let { rg ->
            for (i in 0 until rg.childCount) rg.getChildAt(i).isEnabled = false
        }
        checkBoxes.forEach { it.isEnabled = false }
        editInput?.isEnabled = false
    }

    private fun nextQuestion() {
        if (idx + 1 < items.size) {
            idx++
            render()
        } else {
            finishGroup()
        }
    }

    private fun finishGroup() {
        val passRatio = App.db.cfgInt("passRatio", 70)
        val rate = if (answered > 0) right * 100 / answered else 0

        var reward = starSum
        if (mode != "free" && rate >= passRatio) {
            reward += App.db.cfgInt("unlockPerGroup", 8)
        }

        val added = App.db.addReward(reward)
        App.db.bumpGroup(right, answered)

        quizPanel.visibility = View.GONE
        resultPanel.visibility = View.VISIBLE

        val passed = mode == "free" || rate >= passRatio
        tvResTitle.text = when {
            reviewMode -> if (App.db.mistakeCount() == 0) "错题全清了" else "错题复习完成，还剩 ${App.db.mistakeCount()} 道"
            mode == "free" -> "这一组练完了"
            passed -> "解锁成功"
            else -> "差一点，再来一组"
        }

        tvResStats.text = "答对 $right / $answered 题 · 正确率 $rate%\n达标线 $passRatio%"

        val cap = App.db.earnLimitMin()
        tvResReward.text = when {
            added > 0 -> "这次攒了 $added 分钟，手上共 ${App.db.availableSec() / 60} / $cap 分钟"
            App.db.earnLimitReached() -> "这次额度已经攒满 $cap 分钟，用掉一些才能再攒，这组不加时长"
            else -> "正确率没到 $passRatio%，这组没攒到时长"
        }
    }

    /** 切到后台：回桌面，计时继续 */
    private fun goBackground() {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        } catch (e: Exception) {
        }
        finishAffinity()
    }

    override fun onBackPressed() {
        if (resultPanel.visibility == View.VISIBLE) {
            finish()
            return
        }
        Toast.makeText(this, "这一组答完再走", Toast.LENGTH_SHORT).show()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun initTts() {
        try {
            tts = TextToSpeech(this) { status ->
                ttsReady = status == TextToSpeech.SUCCESS
                if (ttsReady) {
                    try { tts?.language = Locale.CHINA } catch (e: Exception) { }
                }
            }
        } catch (e: Exception) {
        }
    }

    /** 答对给三重反馈：弹字、撒礼花、念一句夸他 */
    private fun praise() {
        val text = praises[Random.nextInt(praises.size)]
        if (ttsReady) {
            try {
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "praise")
            } catch (e: Exception) {
            }
        }
        showPraiseLayer(text)
    }

    private fun showPraiseLayer(text: String) {
        val root = findViewById<ViewGroup>(android.R.id.content)
        praiseLayer?.let { old ->
            try { root.removeView(old) } catch (e: Exception) { }
        }
        val layer = layoutInflater.inflate(R.layout.view_praise, root, false)
        layer.findViewById<TextView>(R.id.tvPraise).text = text
        root.addView(layer)
        praiseLayer = layer
        (layer.findViewById<View>(R.id.praiseFx) as? PraiseView)?.launch()
        layer.postDelayed({
            try { root.removeView(layer) } catch (e: Exception) { }
            if (praiseLayer === layer) praiseLayer = null
        }, PraiseView.DURATION + 200)
    }

    override fun onDestroy() {
        praiseLayer?.let { v ->
            try { (v.parent as? ViewGroup)?.removeView(v) } catch (e: Exception) { }
        }
        praiseLayer = null
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
        ttsReady = false
        super.onDestroy()
    }
}
