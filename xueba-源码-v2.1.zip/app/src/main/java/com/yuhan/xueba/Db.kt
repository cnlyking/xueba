package com.yuhan.xueba

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Db(context: Context) : SQLiteOpenHelper(context.applicationContext, "study.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS cfg(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS q(" +
                "id TEXT PRIMARY KEY, type TEXT, subject TEXT, q TEXT, star INTEGER, " +
                "json TEXT, seen INTEGER DEFAULT 0, wrong INTEGER DEFAULT 0)"
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS day(" +
                "d TEXT PRIMARY KEY, usedSec INTEGER DEFAULT 0, earnedMin INTEGER DEFAULT 0, " +
                "groups INTEGER DEFAULT 0, answered INTEGER DEFAULT 0, right INTEGER DEFAULT 0)"
        )
        db.execSQL("CREATE TABLE IF NOT EXISTS mistake(qid TEXT PRIMARY KEY, added TEXT)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_seen ON q(seen)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---------------- 配置 ----------------

    fun cfg(key: String, def: String): String {
        readableDatabase.rawQuery("SELECT v FROM cfg WHERE k=?", arrayOf(key)).use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return def
    }

    fun cfgInt(key: String, def: Int): Int = cfg(key, def.toString()).toIntOrNull() ?: def

    fun cfgBool(key: String, def: Boolean): Boolean = cfg(key, if (def) "1" else "0") == "1"

    fun setCfg(key: String, value: Any) {
        val cv = ContentValues()
        cv.put("k", key)
        cv.put("v", value.toString())
        writableDatabase.insertWithOnConflict("cfg", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    // ---------------- 题库 ----------------

    fun addQuestions(list: List<Question>, subject: String): Int {
        val db = writableDatabase
        var added = 0
        db.beginTransaction()
        try {
            for (q in list) {
                val cv = ContentValues()
                cv.put("id", q.id)
                cv.put("type", q.type)
                cv.put("subject", subject)
                cv.put("q", q.text)
                cv.put("star", q.star)
                cv.put("json", q.raw)
                cv.put("seen", 0)
                cv.put("wrong", 0)
                val row = db.insertWithOnConflict("q", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
                if (row != -1L) added++
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return added
    }

    fun bankCount(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM q", null).use { c ->
            if (c.moveToFirst()) return c.getInt(0)
        }
        return 0
    }

    fun bankBySubject(): Map<String, Int> {
        val map = LinkedHashMap<String, Int>()
        readableDatabase.rawQuery("SELECT subject, COUNT(*) FROM q GROUP BY subject", null).use { c ->
            while (c.moveToNext()) {
                val s = c.getString(0) ?: "未分类"
                map[s] = c.getInt(1)
            }
        }
        return map
    }

    fun wipeBank() {
        writableDatabase.execSQL("DELETE FROM q")
        writableDatabase.execSQL("DELETE FROM mistake")
    }

    fun allRaw(): List<String> {
        val out = ArrayList<String>()
        readableDatabase.rawQuery("SELECT json FROM q", null).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        return out
    }

    /** 取一组题，优先没做过的 */
    fun takeQuestions(n: Int, subject: String?): List<Question> {
        val out = ArrayList<Question>()
        val filter = if (subject.isNullOrBlank()) "" else " AND subject='" + subject + "'"
        val db = readableDatabase

        db.rawQuery("SELECT id, json FROM q WHERE seen=0$filter ORDER BY RANDOM() LIMIT $n", null).use { c ->
            while (c.moveToNext()) out.add(Question.fromRaw(c.getString(0), c.getString(1)))
        }
        if (out.size < n) {
            val more = n - out.size
            db.rawQuery("SELECT id, json FROM q WHERE seen=1$filter ORDER BY RANDOM() LIMIT $more", null).use { c ->
                while (c.moveToNext()) out.add(Question.fromRaw(c.getString(0), c.getString(1)))
            }
        }
        markSeen(out)
        return out
    }

    private fun markSeen(list: List<Question>) {
        if (list.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (q in list) db.execSQL("UPDATE q SET seen=1 WHERE id=?", arrayOf(q.id))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // ---------------- 错题池 ----------------

    fun addMistake(id: String) {
        val cv = ContentValues()
        cv.put("qid", id)
        cv.put("added", today())
        writableDatabase.insertWithOnConflict("mistake", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun removeMistake(id: String) {
        writableDatabase.delete("mistake", "qid=?", arrayOf(id))
    }

    fun mistakeCount(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM mistake", null).use { c ->
            if (c.moveToFirst()) return c.getInt(0)
        }
        return 0
    }

    fun takeMistakes(n: Int): List<Question> {
        val out = ArrayList<Question>()
        if (n <= 0) return out
        readableDatabase.rawQuery(
            "SELECT q.id, q.json FROM mistake m JOIN q ON q.id=m.qid ORDER BY RANDOM() LIMIT $n",
            null
        ).use { c ->
            while (c.moveToNext()) out.add(Question.fromRaw(c.getString(0), c.getString(1)))
        }
        return out
    }

    // ---------------- 每日统计 ----------------

    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun ensureDay() {
        writableDatabase.execSQL("INSERT OR IGNORE INTO day(d) VALUES('${today()}')")
    }

    private fun dayValue(col: String): Int {
        ensureDay()
        readableDatabase.rawQuery("SELECT $col FROM day WHERE d='${today()}'", null).use { c ->
            if (c.moveToFirst()) return c.getInt(0)
        }
        return 0
    }

    fun usedSec(): Int = dayValue("usedSec")
    fun earnedMin(): Int = dayValue("earnedMin")
    fun groupsDone(): Int = dayValue("groups")
    fun answeredCount(): Int = dayValue("answered")
    fun rightCount(): Int = dayValue("right")

    /** 每次最多积累多少分钟：一轮能攒到的天花板，攒满后要用掉才能再攒，题随时能答 */
    fun earnLimitMin(): Int = cfgInt("dailyLimitMin", 90)

    /** 每天最多使用多少分钟：手机使用总时长的硬上限，到点直接锁，答题也不解锁 */
    fun useLimitMin(): Int = cfgInt("dailyUseLimitMin", 180)

    /** 手上还没用掉的那部分余量 */
    fun availableSec(): Int = (earnedMin() * 60 - usedSec()).coerceAtLeast(0)

    /** 本次额度攒满了：手上的余量已经到了每次上限 */
    fun earnLimitReached(): Boolean = availableSec() >= earnLimitMin() * 60

    fun useLimitReached(): Boolean = usedSec() >= useLimitMin() * 60

    /** 剩余可用秒数：攒到的时长减去已用 */
    fun remainingSec(): Int = availableSec()

    fun addUsed(sec: Int) {
        if (sec <= 0) return
        ensureDay()
        writableDatabase.execSQL("UPDATE day SET usedSec = usedSec + $sec WHERE d='${today()}'")
    }

    /** 加时长，受「每次积累上限」约束，返回真正加了多少分钟 */
    fun addReward(minutes: Int): Int {
        if (minutes <= 0) return 0
        ensureDay()
        if (useLimitReached()) return 0
        val roomMin = ((earnLimitMin() * 60 - availableSec()) / 60).coerceAtLeast(0)
        val add = minutes.coerceAtMost(roomMin)
        if (add > 0) {
            writableDatabase.execSQL("UPDATE day SET earnedMin = earnedMin + $add WHERE d='${today()}'")
        }
        return add
    }

    fun bumpGroup(right: Int, answered: Int) {
        ensureDay()
        writableDatabase.execSQL(
            "UPDATE day SET groups = groups + 1, answered = answered + $answered, right = right + $right WHERE d='${today()}'"
        )
    }

    fun resetToday() {
        ensureDay()
        writableDatabase.execSQL(
            "UPDATE day SET usedSec=0, earnedMin=0, groups=0, answered=0, right=0 WHERE d='${today()}'"
        )
    }
}
