package com.yuhan.xueba

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 系统里卸载 / 停用本应用时，弹家长密码页。
 * Android 不允许应用阻止自己被卸载，只能靠辅助功能在系统卸载页拦一道。
 * 注意：系统设置页会屏蔽第三方悬浮窗，所以这里启动自己的 Activity，而不是盖 overlay。
 */
class UninstallGuardService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            e.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) return
        if (e.packageName?.toString() == packageName) return
        if (GuardGate.showing) return
        if (System.currentTimeMillis() - GuardGate.lastPromptAt < 2500L) return
        if (System.currentTimeMillis() < GuardGate.passUntil) return

        val savedPin = try {
            App.db.cfg("pin", "")
        } catch (ex: Exception) {
            ""
        }
        if (savedPin.isBlank()) return

        val texts = (collect() + " " + (e.text?.joinToString(" ") ?: "")).lowercase()
        if (!texts.contains("成为学霸") && !texts.contains("xueba")) return

        val danger = listOf(
            "卸载", "取消激活", "停用", "强行停止", "移除",
            "uninstall", "deactivate", "disable", "force stop", "force-stop"
        ).any { texts.contains(it) }
        if (!danger) return

        android.util.Log.d("UninstallGuard", "命中，弹密码页")
        GuardGate.lastPromptAt = System.currentTimeMillis()
        try {
            val i = Intent(this, GuardActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(i)
        } catch (ex: Exception) {
            android.util.Log.e("UninstallGuard", "startActivity failed: " + ex)
            GuardGate.lastPromptAt = 0L
        }
    }

    override fun onInterrupt() {}

    private fun collect(): String {
        val sb = StringBuilder()
        try {
            windows.forEach { w ->
                try {
                    val pkg = w.root?.packageName?.toString()
                    // 自己 App 的界面不算，否则说明文字里提到"卸载"也会误弹
                    if (pkg == packageName) return@forEach
                    walk(w.root, sb, 0)
                } catch (e: Exception) {
                }
            }
            if (sb.isEmpty()) rootInActiveWindow?.let { walk(it, sb, 0) }
        } catch (e: Exception) {
        }
        return sb.toString()
    }

    private fun walk(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 30) return
        node.text?.let { if (it.isNotBlank()) sb.append(it).append(' ') }
        node.contentDescription?.let { if (it.isNotBlank()) sb.append(it).append(' ') }
        for (i in 0 until node.childCount) walk(node.getChild(i), sb, depth + 1)
    }

    companion object {
        /** 辅助功能是系统绑定的特权服务，从它这里启动界面被厂商拦的概率低得多 */
        @Volatile
        var instance: UninstallGuardService? = null
            private set
    }
}
