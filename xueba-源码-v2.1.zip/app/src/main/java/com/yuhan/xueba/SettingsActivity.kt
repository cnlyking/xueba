package com.yuhan.xueba

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import java.io.FileNotFoundException

class SettingsActivity : AppCompatActivity() {

    private lateinit var etDaily: EditText
    private lateinit var etUseLimit: EditText
    private lateinit var etUnlock: EditText
    private lateinit var etGroupSize: EditText
    private lateinit var etPass: EditText
    private lateinit var etS1: EditText
    private lateinit var etS2: EditText
    private lateinit var etS3: EditText
    private lateinit var etS4: EditText
    private lateinit var etS5: EditText
    private lateinit var etMistakeTh: EditText
    private lateinit var etMistakeExtra: EditText
    private lateinit var etNewPin: EditText
    private lateinit var rgMode: RadioGroup
    private lateinit var swTip: SwitchCompat
    private lateinit var tvBank: TextView
    private lateinit var tvPerm: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        etDaily = findViewById(R.id.etDaily)
        etUseLimit = findViewById(R.id.etUseLimit)
        etUnlock = findViewById(R.id.etUnlock)
        etGroupSize = findViewById(R.id.etGroupSize)
        etPass = findViewById(R.id.etPass)
        etS1 = findViewById(R.id.etS1)
        etS2 = findViewById(R.id.etS2)
        etS3 = findViewById(R.id.etS3)
        etS4 = findViewById(R.id.etS4)
        etS5 = findViewById(R.id.etS5)
        etMistakeTh = findViewById(R.id.etMistakeTh)
        etMistakeExtra = findViewById(R.id.etMistakeExtra)
        etNewPin = findViewById(R.id.etNewPin)
        rgMode = findViewById(R.id.rgMode)
        swTip = findViewById(R.id.swTip)
        tvBank = findViewById(R.id.tvBank)
        tvPerm = findViewById(R.id.tvPerm)

        load()
        setupClearOnFocus()

        findViewById<android.view.View>(R.id.btnSave).setOnClickListener { save() }
        findViewById<android.view.View>(R.id.btnImport).setOnClickListener { doImport() }
        findViewById<android.view.View>(R.id.btnExport).setOnClickListener { doExport() }
        findViewById<android.view.View>(R.id.btnClearBank).setOnClickListener { confirmClear() }
        findViewById<android.view.View>(R.id.btnSavePin).setOnClickListener { savePin() }
        findViewById<android.view.View>(R.id.btnOverlay).setOnClickListener {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                Toast.makeText(this, "请手动到系统设置里开悬浮窗权限", Toast.LENGTH_LONG).show()
            }
        }
        findViewById<android.view.View>(R.id.btnResetToday).setOnClickListener { confirmReset() }
    }

    override fun onResume() {
        super.onResume()
        refreshBank()
        refreshPerm()
    }

    private fun load() {
        etDaily.setText(App.db.cfgInt("dailyLimitMin", 90).toString())
        etUseLimit.setText(App.db.cfgInt("dailyUseLimitMin", 180).toString())
        etUnlock.setText(App.db.cfgInt("unlockPerGroup", 8).toString())
        etGroupSize.setText(App.db.cfgInt("groupSize", 8).toString())
        etPass.setText(App.db.cfgInt("passRatio", 70).toString())
        etS1.setText(App.db.cfgInt("star1", 1).toString())
        etS2.setText(App.db.cfgInt("star2", 1).toString())
        etS3.setText(App.db.cfgInt("star3", 2).toString())
        etS4.setText(App.db.cfgInt("star4", 2).toString())
        etS5.setText(App.db.cfgInt("star5", 3).toString())
        etMistakeTh.setText(App.db.cfgInt("mistakeTh", 3).toString())
        etMistakeExtra.setText(App.db.cfgInt("mistakeExtra", 3).toString())

        when (App.db.cfg("mode", "group")) {
            "streak" -> rgMode.check(R.id.rbStreak)
            "free" -> rgMode.check(R.id.rbFree)
            else -> rgMode.check(R.id.rbGroup)
        }
        swTip.isChecked = App.db.cfgBool("showTip", true)
    }

    private fun save() {
        App.db.setCfg("dailyLimitMin", etDaily.number(90, 5, 600))
        App.db.setCfg("dailyUseLimitMin", etUseLimit.number(180, 30, 1440))
        App.db.setCfg("unlockPerGroup", etUnlock.number(8, 1, 180))
        App.db.setCfg("groupSize", etGroupSize.number(8, 3, 30))
        App.db.setCfg("passRatio", etPass.number(70, 20, 100))
        App.db.setCfg("star1", etS1.number(1, 0, 30))
        App.db.setCfg("star2", etS2.number(1, 0, 30))
        App.db.setCfg("star3", etS3.number(2, 0, 30))
        App.db.setCfg("star4", etS4.number(2, 0, 30))
        App.db.setCfg("star5", etS5.number(3, 0, 30))
        App.db.setCfg("mistakeTh", etMistakeTh.number(3, 1, 50))
        App.db.setCfg("mistakeExtra", etMistakeExtra.number(3, 1, 30))

        val mode = when (rgMode.checkedRadioButtonId) {
            R.id.rbStreak -> "streak"
            R.id.rbFree -> "free"
            else -> "group"
        }
        App.db.setCfg("mode", mode)
        App.db.setCfg("showTip", if (swTip.isChecked) "1" else "0")

        load()
        Toast.makeText(this, "设置已保存，马上生效", Toast.LENGTH_SHORT).show()
    }

    private fun savePin() {
        val pin = etNewPin.text.toString().trim()
        if (pin.length !in 4..6 || pin.toIntOrNull() == null) {
            Toast.makeText(this, "密码要 4–6 位数字", Toast.LENGTH_SHORT).show()
            return
        }
        App.db.setCfg("pin", pin)
        etNewPin.setText("")
        Toast.makeText(this, "密码已更新", Toast.LENGTH_SHORT).show()
    }

    private fun refreshBank() {
        val count = App.db.bankCount()
        val bySubject = App.db.bankBySubject()
        val detail = if (bySubject.isEmpty()) "" else bySubject.entries.joinToString(" · ") { "${it.key} ${it.value}" }
        tvBank.text = "共 $count 题" + if (detail.isNotBlank()) "\n$detail" else ""
    }

    private fun refreshPerm() {
        val ok = Settings.canDrawOverlays(this)
        tvPerm.text = if (ok)
            "悬浮窗权限：已开启，时间到会跳回前台并锁住。\n华为/小米手机还要在主页「后台与卸载保护」里打开「后台弹出界面」，不然跳不过来。"
        else
            "悬浮窗权限：未开启，时间到只能弹通知提醒，拦不住别的应用"
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("清空题库")
            .setMessage("会把当前所有题目和错题本一起删掉，导入前先想好。")
            .setPositiveButton("确定清空") { _, _ ->
                App.db.wipeBank()
                refreshBank()
                Toast.makeText(this, "题库已清空", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("清空今天记录")
            .setMessage("今日已获得时长、已用时长、答题组数都会归零，方便重新试。")
            .setPositiveButton("确定") { _, _ ->
                App.db.resetToday()
                Toast.makeText(this, "今天的记录已清零", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun doImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivityForResult(intent, REQ_IMPORT)
        } catch (e: Exception) {
            Toast.makeText(this, "没有可用的文件选择器", Toast.LENGTH_SHORT).show()
        }
    }

    private fun doExport() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "题了个题题库.json")
        }
        try {
            startActivityForResult(intent, REQ_EXPORT)
        } catch (e: Exception) {
            Toast.makeText(this, "没有可用的文件选择器", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            REQ_IMPORT -> {
                try {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    if (text.isNullOrBlank()) {
                        Toast.makeText(this, "文件是空的", Toast.LENGTH_SHORT).show()
                        return
                    }
                    val added = BankIO.importJson(App.db, text)
                    refreshBank()
                    Toast.makeText(this, "导入了 $added 道新题", Toast.LENGTH_SHORT).show()
                } catch (e: FileNotFoundException) {
                    Toast.makeText(this, "读不到这个文件", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "题库格式不对：${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            REQ_EXPORT -> {
                try {
                    val json = BankIO.exportJson(App.db)
                    contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(this, "已导出 ${App.db.bankCount()} 道题", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "导出失败：${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun EditText.number(def: Int, min: Int, max: Int): Int {
        val raw = text.toString().trim().toIntOrNull() ?: def
        return raw.coerceIn(min, max)
    }

    /** 数字框点进去先自动清空，省得每次都要按退格；什么都没输就走，把原值填回去 */
    private fun setupClearOnFocus() {
        val boxes = listOf(
            etDaily, etUseLimit, etUnlock, etGroupSize, etPass,
            etS1, etS2, etS3, etS4, etS5, etMistakeTh, etMistakeExtra, etNewPin
        )
        for (et in boxes) {
            et.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    et.tag = et.text.toString()
                    et.setText("")
                } else if (et.text.isNullOrBlank()) {
                    val old = et.tag as? String
                    if (!old.isNullOrBlank()) et.setText(old)
                }
            }
        }
    }

    companion object {
        private const val REQ_IMPORT = 2001
        private const val REQ_EXPORT = 2002
    }
}
