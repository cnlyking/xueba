package com.yuhan.xueba

/**
 * 卸载拦截的开关状态，服务与 Activity 同一进程共用。
 */
object GuardGate {
    /** 输对密码后的放行截止时间 */
    var passUntil = 0L

    /** 密码页是否正压在系统页面上 */
    var showing = false

    /** 上次启动密码页的时刻，防止短时间内重复弹 */
    var lastPromptAt = 0L
}
