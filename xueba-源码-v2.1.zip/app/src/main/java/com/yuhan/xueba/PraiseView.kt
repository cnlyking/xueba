package com.yuhan.xueba

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** 答对时撒的礼花：纯 Canvas 画的彩色纸片，不依赖任何图片资源 */
class PraiseView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private class Dot(
        var x: Float,
        var y: Float,
        var vx: Float,
        var vy: Float,
        val size: Float,
        val color: Int,
        var rot: Float,
        val vr: Float,
        val rect: Boolean
    )

    private val dots = ArrayList<Dot>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var startAt = 0L
    private var running = false

    private val palette = intArrayOf(
        0xFFFF5A5F.toInt(), 0xFFFFC93C.toInt(), 0xFF3ECF8E.toInt(),
        0xFF4D9DE0.toInt(), 0xFFB07CF0.toInt(), 0xFFFF8B3D.toInt()
    )

    init {
        visibility = GONE
    }

    fun launch() {
        dots.clear()
        val w = if (width > 0) width.toFloat() else resources.displayMetrics.widthPixels.toFloat()
        val h = if (height > 0) height.toFloat() else resources.displayMetrics.heightPixels.toFloat()
        val cx = w / 2f
        val cy = h * 0.32f
        for (i in 0 until 96) {
            val angle = Random.nextFloat() * Math.PI.toFloat() * 2f
            val speed = Random.nextFloat() * 13f + 7f
            dots.add(
                Dot(
                    cx + (Random.nextFloat() - 0.5f) * 40f,
                    cy + (Random.nextFloat() - 0.5f) * 30f,
                    cos(angle) * speed,
                    sin(angle) * speed - 5f,
                    Random.nextFloat() * 9f + 8f,
                    palette[Random.nextInt(palette.size)],
                    Random.nextFloat() * 360f,
                    (Random.nextFloat() - 0.5f) * 22f,
                    Random.nextBoolean()
                )
            )
        }
        startAt = System.currentTimeMillis()
        running = true
        visibility = VISIBLE
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!running) return

        val elapsed = System.currentTimeMillis() - startAt
        if (elapsed > DURATION) {
            running = false
            visibility = GONE
            return
        }
        val alpha = if (elapsed > DURATION - 320) {
            ((DURATION - elapsed) / 320f * 255f).toInt().coerceIn(0, 255)
        } else 255

        for (d in dots) {
            d.vy += 0.55f
            d.vx *= 0.988f
            d.x += d.vx
            d.y += d.vy
            d.rot += d.vr
            paint.color = d.color
            paint.alpha = alpha
            canvas.save()
            canvas.rotate(d.rot, d.x, d.y)
            if (d.rect) {
                canvas.drawRect(d.x - d.size / 2f, d.y - d.size / 4f, d.x + d.size / 2f, d.y + d.size / 4f, paint)
            } else {
                canvas.drawCircle(d.x, d.y, d.size / 2f, paint)
            }
            canvas.restore()
        }
        invalidate()
    }

    companion object {
        const val DURATION = 1300L
    }
}
