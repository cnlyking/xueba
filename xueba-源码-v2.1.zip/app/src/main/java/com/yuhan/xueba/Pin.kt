package com.yuhan.xueba

import android.app.Activity
import android.content.DialogInterface
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

object Pin {

    fun isSet(): Boolean = App.db.cfg("pin", "").isNotBlank()

    /** 需要家长密码才能继续，未设置过则先让家长设一个 */
    fun require(activity: Activity, onOk: () -> Unit) {
        val saved = App.db.cfg("pin", "")
        if (saved.isBlank()) {
            createNew(activity, onOk)
            return
        }
        val view = activity.layoutInflater.inflate(R.layout.dialog_pin, null)
        val et = view.findViewById<EditText>(R.id.etPin)
        val et2 = view.findViewById<EditText>(R.id.etPin2)
        et2.viewGone()
        val dlg = AlertDialog.Builder(activity)
            .setTitle("家长验证")
            .setView(view)
            .setPositiveButton("确定", null)
            .setNegativeButton("取消", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                if (et.text.toString().trim() == saved) {
                    dlg.dismiss()
                    onOk()
                } else {
                    Toast.makeText(activity, "密码不对", Toast.LENGTH_SHORT).show()
                    et.setText("")
                }
            }
        }
        dlg.show()
    }

    /** 设置新密码 */
    fun createNew(activity: Activity, onOk: () -> Unit) {
        val view = activity.layoutInflater.inflate(R.layout.dialog_pin, null)
        val et = view.findViewById<EditText>(R.id.etPin)
        val et2 = view.findViewById<EditText>(R.id.etPin2)
        et2.viewVisible()
        val dlg = AlertDialog.Builder(activity)
            .setTitle("设置家长密码")
            .setView(view)
            .setCancelable(false)
            .setPositiveButton("保存", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val a = et.text.toString().trim()
                val b = et2.text.toString().trim()
                if (a.length !in 4..6 || a.toIntOrNull() == null) {
                    Toast.makeText(activity, "密码要 4–6 位数字", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (a != b) {
                    Toast.makeText(activity, "两次输入不一致", Toast.LENGTH_SHORT).show()
                    et2.setText("")
                    return@setOnClickListener
                }
                App.db.setCfg("pin", a)
                dlg.dismiss()
                Toast.makeText(activity, "密码已保存，请记牢", Toast.LENGTH_SHORT).show()
                onOk()
            }
        }
        dlg.show()
    }

    private fun View.viewGone() {
        visibility = View.GONE
    }

    private fun View.viewVisible() {
        visibility = View.VISIBLE
    }
}
