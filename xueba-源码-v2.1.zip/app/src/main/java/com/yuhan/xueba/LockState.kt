package com.yuhan.xueba

/**
 * 时间用完之后的锁屏状态，后台服务、锁屏页、主页三方共用。
 * locked 由 OverlayService 每隔几秒刷新一次，避免界面里反复读数据库。
 */
object LockState {

    /** 今天的时间是不是已经用完 */
    @Volatile
    var locked = false

    /** 锁屏页是不是正压在最前面 */
    @Volatile
    var showing = false

    /** 家长输密码后的放行截止时间 */
    @Volatile
    var passUntil = 0L

    /** 上次拉起锁屏页的时刻，防止一秒内反复启动 */
    @Volatile
    var lastLaunchAt = 0L

    fun passed(): Boolean = System.currentTimeMillis() < passUntil

    /** 该锁着：时间用完，且家长没放行 */
    fun active(): Boolean = locked && !passed()

    fun passFor(minutes: Int) {
        passUntil = System.currentTimeMillis() + minutes * 60_000L
    }
}
