package com.yuhan.xueba

import org.json.JSONObject
import java.security.MessageDigest

data class Question(
    val id: String,
    val type: String,
    val text: String,
    val options: List<String>,
    val k: Int,
    val correct: List<Int>,
    val answers: List<String>,
    val star: Int,
    val tip: String,
    val modelAnswer: String,
    val raw: String
) {

    val isObjective: Boolean
        get() = type != "subjective"

    /** 正确答案的文字形式，用于答题后展示 */
    fun answerText(): String = when (type) {
        "multiple" -> correct.sorted().joinToString("、") { options.getOrElse(it) { "" } }
        "text" -> answers.joinToString(" / ")
        "subjective" -> modelAnswer
        else -> options.getOrElse(k) { "" }
    }

    /**
     * 判分。sel 是选项下标集合，input 是填空/主观题的输入。
     * 主观题这里恒为 true，由孩子对照参考答案自评。
     */
    fun judge(sel: List<Int>, input: String?): Boolean = when (type) {
        "multiple" -> sel.toSet() == correct.toSet() && correct.isNotEmpty()
        "text" -> answers.any { norm(it) == norm(input ?: "") }
        "subjective" -> true
        else -> sel.size == 1 && sel[0] == k
    }

    companion object {

        fun fromRaw(id: String, raw: String): Question {
            val o = JSONObject(raw)
            return build(id, o)
        }

        /** 从题库文件里的一条 item 解析，解析失败返回 null */
        fun parse(o: JSONObject): Question? {
            val text = o.optString("q", "").trim()
            if (text.isEmpty()) return null
            val id = o.optString("id", "").trim().ifBlank { md5(text) }
            return build(id, o)
        }

        private fun build(id: String, o: JSONObject): Question {
            val type = o.optString("type", "single").ifBlank { "single" }
            val text = o.optString("q", "")
            val options = ArrayList<String>()
            o.optJSONArray("a")?.let { arr ->
                for (i in 0 until arr.length()) options.add(arr.optString(i))
            }
            if (type == "boolean" && options.isEmpty()) {
                options.add("正确")
                options.add("错误")
            }
            val correct = ArrayList<Int>()
            o.optJSONArray("correctIndices")?.let { arr ->
                for (i in 0 until arr.length()) correct.add(arr.optInt(i))
            }
            if (type == "multiple" && correct.isEmpty()) {
                o.optInt("k", -1).let { if (it >= 0) correct.add(it) }
            }
            val answers = ArrayList<String>()
            o.optJSONArray("answers")?.let { arr ->
                for (i in 0 until arr.length()) answers.add(arr.optString(i))
            }
            val star = o.optInt("difficulty", 2).coerceIn(1, 5)
            return Question(
                id = id,
                type = type,
                text = text,
                options = options,
                k = o.optInt("k", 0),
                correct = correct,
                answers = answers,
                star = star,
                tip = o.optString("tip", ""),
                modelAnswer = o.optString("modelAnswer", ""),
                raw = o.toString()
            )
        }

        private fun md5(s: String): String {
            val md = MessageDigest.getInstance("MD5")
            val bytes = md.digest(s.toByteArray(Charsets.UTF_8))
            val sb = StringBuilder()
            for (b in bytes) sb.append(String.format("%02x", b))
            return "q" + sb.substring(0, 16)
        }

        /** 填空判分用的归一化：去空白、去标点、全角转半角、大小写不敏感 */
        fun norm(s: String): String {
            val sb = StringBuilder()
            for (ch0 in s.trim().lowercase()) {
                if (ch0.isWhitespace()) continue
                val ch = when (ch0) {
                    in '０'..'９' -> '0' + (ch0 - '０')
                    in 'ａ'..'ｚ' -> 'a' + (ch0 - 'ａ')
                    in 'Ａ'..'Ｚ' -> 'A' + (ch0 - 'Ａ')
                    '．' -> '.'
                    '，' -> ','
                    '－', '—' -> '-'
                    '／' -> '/'
                    else -> ch0
                }
                if (ch in "，。！？；：、“”‘’（）《》【】…·") continue
                sb.append(ch)
            }
            return sb.toString()
        }
    }
}
