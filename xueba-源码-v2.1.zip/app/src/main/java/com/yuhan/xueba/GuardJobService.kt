package com.yuhan.xueba

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat

/** 系统把服务干掉以后，靠这个周期任务再拉回来 */
class GuardJobService : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        Guard.start(this)
        return false
    }

    override fun onStopJob(params: JobParameters?): Boolean = true
}

object Guard {

    const val JOB_ID = 2001

    fun start(ctx: Context) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
        } catch (e: Exception) {
            // 后台启动受限，等下次机会
        }
    }

    fun schedule(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return
        try {
            val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            val info = JobInfo.Builder(JOB_ID, ComponentName(ctx, GuardJobService::class.java))
                .setPeriodic(15 * 60 * 1000L)
                .setPersisted(true)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_NONE)
                .build()
            js.schedule(info)
        } catch (e: Exception) {
        }
    }

    fun isIgnoringBattery(ctx: Context): Boolean {
        return try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) pm.isIgnoringBatteryOptimizations(ctx.packageName) else true
        } catch (e: Exception) {
            false
        }
    }
}
