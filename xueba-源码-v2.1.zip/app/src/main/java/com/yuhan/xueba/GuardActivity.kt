package com.yuhan.xueba

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

/**
 * 在系统卸载 / 取消激活页面前面弹家长密码。
 * 系统设置页会屏蔽第三方悬浮窗，所以这里用真正的 Activity 盖上去。
 */
class GuardActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_uninstall_guard)

        val et = findViewById<EditText>(R.id.etGuardPin)
        val msg = findViewById<TextView>(R.id.tvGuardMsg)

        findViewById<View>(R.id.btnGuardOk).setOnClickListener {
            val input = et.text.toString().trim()
            val saved = try {
                App.db.cfg("pin", "")
            } catch (e: Exception) {
                ""
            }
            if (saved.isNotBlank() && input == saved) {
                GuardGate.passUntil = System.currentTimeMillis() + 60_000L
                Toast.makeText(this, "已放行，60 秒内不再拦", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                et.setText("")
                msg.text = "密码不对。卸载或停用「成为学霸」要家长自己来。"
                Toast.makeText(this, "密码不正确", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<View>(R.id.btnGuardCancel).setOnClickListener {
            finish()
            try {
                val home = Intent(Intent.ACTION_MAIN)
                home.addCategory(Intent.CATEGORY_HOME)
                home.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(home)
            } catch (e: Exception) {
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // 密码页压在最前面时别再重复弹
        GuardGate.showing = true
    }

    override fun onPause() {
        // 被切走就恢复拦截
        GuardGate.showing = false
        super.onPause()
    }

    override fun onDestroy() {
        GuardGate.showing = false
        super.onDestroy()
    }

    override fun onBackPressed() {
        // 返回键等同放弃
        findViewById<View>(R.id.btnGuardCancel).performClick()
    }
}
